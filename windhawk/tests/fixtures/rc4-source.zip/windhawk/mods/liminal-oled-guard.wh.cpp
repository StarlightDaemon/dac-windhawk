// ==WindhawkMod==
// @id              oled-aegis
// @name            Liminal OLED Guard
// @description     Activity-aware OLED protection and per-monitor screensavers
// @version         1.0.0-rc.4
// @author          Liminal OLED Guard contributors
// @include         windhawk.exe
// @architecture    x86
// @architecture    x86-64
// @compilerOptions -lshell32 -luser32 -lgdi32 -lole32 -luuid -lwtsapi32 -lcomdlg32 -ladvapi32 -lpowrprof -ldwmapi -ldxva2 -lgdiplus
// ==/WindhawkMod==

// ==WindhawkModReadme==
/*
# Liminal OLED Guard
Activity-aware OLED protection and per-monitor screensavers.
Reduces prolonged static-image exposure; does not guarantee burn-in prevention.
Update the existing local mod in place; its oled-aegis ID and settings remain compatible.
Use the tray > Settings to configure the single versioned configuration.
Automatic activation defaults OFF. Windhawk must run at logon for startup.
Ctrl+Alt+Shift+F12 stops and exits the dedicated tool host.
Stock Windows savers are discovered locally, never downloaded or bundled.
Preview-window detection is a startup heuristic, not rendering qualification.
Hardware power control is opt-in and monitor-dependent; physical wake may be needed.
Settings use the Fujin light/dark palette, following Windows app appearance;
high contrast uses Windows colors. The monitor/shield tray icon marks protection.
See windhawk/docs/LIMINAL_RC4.md for changes, upgrade steps and testing.
Built for Windhawk. Original-source licensing and public release remain pending;
this is a local testing candidate. Factual lineage is retained in PROVENANCE.md.
Dependencies/notices: windhawk/docs/PROVENANCE.md and THIRD_PARTY_NOTICES.md.
*/
// ==/WindhawkModReadme==

// Original production implementation; reviewed prototype adaptations recorded
// in PROVENANCE.md. This file is the complete Windhawk source distribution.
#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <map>
#include <memory>
#include <mutex>
#include <set>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#include <random>
#include <cmath>

namespace aegis {
using Time = uint64_t;
struct Preference {
    bool enabled=true; int saver=-1; // -1: native black
    int timeout=0,input=-1,media=-1,blackAfter=0;
    bool hardware=false; int powerAfter=0; bool fullscreen=false;
    std::string custom{},folder{};int slideSeconds=30,placement=0,background=0;bool shuffle=false,recursive=false;
};
std::string Canonical(std::string s) {
    if(s.find('\\')!=std::string::npos) for(char& c:s) if(c>='A'&&c<='Z') c+=32;
    return s;
}
struct Config {
    int timeout=300, poll=1000, padding=0;
    bool automatic=false, perInput=false, media=true, perMedia=true, muted=false, debug=false;
    bool hotkeys=false;int currentKey=11,allKey=10;
    std::map<std::string,Preference> monitors;
};
void Validate(Config& c) {
    c.timeout=std::clamp(c.timeout,5,3600); c.poll=std::clamp(c.poll,250,10000);
    c.padding=std::clamp(c.padding,0,1024);
    for(auto& [id,p]:c.monitors) {
        (void)id; p.saver=std::clamp(p.saver,-1,7);
        p.timeout=p.timeout==0?0:std::clamp(p.timeout,5,3600);
        p.input=std::clamp(p.input,-1,1);p.media=std::clamp(p.media,-1,1);
        p.blackAfter=p.blackAfter==0?0:std::clamp(p.blackAfter,5,86400);
        p.powerAfter=p.powerAfter==0?0:std::clamp(p.powerAfter,5,86400);
        p.slideSeconds=std::clamp(p.slideSeconds,5,3600);p.placement=std::clamp(p.placement,0,5);p.background=std::clamp(p.background,0,0xffffff);
    }
    c.currentKey=std::clamp(c.currentKey,1,12);c.allKey=std::clamp(c.allKey,1,12);
}
std::string Trim(std::string s) {
    auto a=s.find_first_not_of(" \t\r\n"), b=s.find_last_not_of(" \t\r\n");
    return a==std::string::npos?"":s.substr(a,b-a+1);
}
bool Number(const std::string& s,int& n) {
    if(s.empty() || s.size()>10) return false;
    int64_t value=0; size_t i=s[0]=='-'?1:0; if(i==s.size()) return false;
    for(;i<s.size();++i) { if(s[i]<'0'||s[i]>'9') return false; value=value*10+s[i]-'0'; if(value>2147483647) return false; }
    n=static_cast<int>(s[0]=='-'?-value:value); return true;
}
std::string Hex(const std::string& s) {
    const char* digits="0123456789abcdef"; std::string out;
    for(unsigned char ch:s) { out+=digits[ch>>4]; out+=digits[ch&15]; } return out;
}
bool Unhex(const std::string& s,std::string& out) {
    if(s.empty()||s.size()%2||s.size()>8192) return false; out.clear();
    auto digit=[](char c) { return c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:-1; };
    for(size_t i=0;i<s.size();i+=2) { int a=digit(s[i]),b=digit(s[i+1]); if(a<0||b<0||!(a*16+b)) return false; out+=char(a*16+b); } return true;
}
std::string Serialize(Config c) {
    Validate(c); std::ostringstream o;
    o<<"version=2\ntimeout="<<c.timeout<<"\npoll="<<c.poll<<"\npadding="<<c.padding
     <<"\nautomatic="<<c.automatic<<"\nperInput="<<c.perInput<<"\nmedia="<<c.media
     <<"\nperMedia="<<c.perMedia<<"\nmuted="<<c.muted<<"\ndebug="<<c.debug<<'\n'
     <<"hotkeys="<<c.hotkeys<<"\ncurrentKey="<<c.currentKey<<"\nallKey="<<c.allKey<<'\n';
    for(auto& [id,p]:c.monitors) {
        o<<"monitor."<<Hex(id)<<'='<<p.enabled<<','<<p.saver<<'\n';
        o<<"policy."<<Hex(id)<<'='<<p.timeout<<','<<p.input<<','<<p.media<<','<<p.blackAfter<<','<<p.hardware<<','<<p.powerAfter<<','<<p.fullscreen<<'\n';
        o<<"assets."<<Hex(id)<<'='<<Hex(p.custom)<<'|'<<Hex(p.folder)<<'|'<<p.slideSeconds<<'|'<<p.placement<<'|'<<p.shuffle<<'|'<<p.recursive<<'|'<<p.background<<'\n';
    }
    return o.str();
}
bool Parse(const std::string& text,Config& result,std::string& error) {
    if(text.size()>262144) { error="Configuration exceeds 256 KiB"; return false; }
    Config c; bool version=false; std::set<std::string> keys; std::istringstream in(text); std::string line;
    while(std::getline(in,line)) {
        line=Trim(line); if(line.empty()||line[0]=='#') continue;
        auto eq=line.find('='); if(eq==std::string::npos) { error="Expected key=value"; return false; }
        auto k=Trim(line.substr(0,eq)),v=Trim(line.substr(eq+1)); int n=0;
        if(!keys.insert(k).second) { error="Duplicate key"; return false; }
        if(k.starts_with("assets.")) {
            std::string id;if(!Unhex(k.substr(7),id)){error="Invalid asset identity";return false;}id=Canonical(id);
            if(!keys.insert("canonical-assets:"+id).second){error="Duplicate asset identity";return false;}
            std::istringstream fields(v);std::string field;std::vector<std::string> values;while(std::getline(fields,field,'|'))values.push_back(field);
            if(values.size()!=7||v.ends_with('|')){error="Invalid asset fields";return false;}
            auto& p=c.monitors[id];int nums[5]{};for(int i=0;i<5;++i)if(!Number(values[i+2],nums[i])){error="Invalid asset integer";return false;}
            if((!values[0].empty()&&!Unhex(values[0],p.custom))||(!values[1].empty()&&!Unhex(values[1],p.folder))||nums[2]<0||nums[2]>1||nums[3]<0||nums[3]>1){error="Invalid asset value";return false;}
            p.slideSeconds=nums[0];p.placement=nums[1];p.shuffle=nums[2];p.recursive=nums[3];p.background=nums[4];continue;
        }
        if(k.starts_with("policy.")) {
            std::string id;if(!Unhex(k.substr(7),id)) {error="Invalid policy identity";return false;}
            id=Canonical(id);std::istringstream fields(v);std::string field;std::vector<int> values;
            if(!keys.insert("canonical-policy:"+id).second){error="Duplicate policy identity";return false;}
            while(std::getline(fields,field,',')) {int item;if(!Number(field,item)){error="Invalid monitor policy";return false;}values.push_back(item);}
            if(values.size()!=7||v.ends_with(',')||values[1]<-1||values[1]>1||values[2]<-1||values[2]>1||values[4]<0||values[4]>1||values[6]<0||values[6]>1){error="Invalid monitor policy fields";return false;}
            auto& p=c.monitors[id];p.timeout=values[0];p.input=values[1];p.media=values[2];p.blackAfter=values[3];p.hardware=values[4]!=0;p.powerAfter=values[5];p.fullscreen=values[6]!=0;continue;
        }
        if(k.starts_with("monitor.")) {
            auto comma=v.find(','); std::string id; int en=0,saver=0;
            if(!Unhex(k.substr(8),id)||comma==std::string::npos||!Number(v.substr(0,comma),en)||en<0||en>1||!Number(v.substr(comma+1),saver)) { error="Invalid monitor preference"; return false; }
            id=Canonical(id); if(!keys.insert("canonical-monitor:"+id).second) {error="Duplicate monitor identity";return false;}
            c.monitors[id].enabled=en!=0;c.monitors[id].saver=saver; continue;
        }
        if(!Number(v,n)) { error="Expected integer"; return false; }
        if(k=="version") { if(n!=1&&n!=2) { error="Unsupported version"; return false; } version=true; }
        else if(k=="timeout") c.timeout=n; else if(k=="poll") c.poll=n; else if(k=="padding") c.padding=n;
        else if(k=="currentKey")c.currentKey=n;else if(k=="allKey")c.allKey=n;
        else {
            if(n<0||n>1) { error="Expected 0 or 1"; return false; }
            if(k=="automatic") c.automatic=n; else if(k=="perInput") c.perInput=n;
            else if(k=="media") c.media=n; else if(k=="perMedia") c.perMedia=n;
            else if(k=="muted") c.muted=n; else if(k=="debug") c.debug=n;
            else if(k=="hotkeys")c.hotkeys=n;
            else { error="Unknown configuration key"; return false; }
        }
    }
    if(!version) { error="Missing version"; return false; }
    Validate(c); result=std::move(c); return true;
}
template<class Store> bool Commit(Config& live,Config next,Store save) {
    Validate(next); if(!save(Serialize(next))) return false; live=std::move(next); return true;
}
struct Geometry { int64_t left,top,right,bottom; };
Geometry Padded(Geometry r,int padding) { int p=std::clamp(padding,0,1024); return {r.left-p,r.top-p,r.right+p,r.bottom+p}; }
bool MediaOverlap(Geometry window,Geometry display) {
    auto width=std::max<int64_t>(0,std::min(window.right,display.right)-std::max(window.left,display.left));
    auto height=std::max<int64_t>(0,std::min(window.bottom,display.bottom)-std::max(window.top,display.top));
    auto area=width*height,total=std::max<int64_t>(0,window.right-window.left)*std::max<int64_t>(0,window.bottom-window.top);
    return total>0&&area>=4096&&area*20>=total;
}
enum class State { Disabled,Desktop,Suppressed,Black,Launching,Saver,Fallback };
bool Running(State s) { return s==State::Black||s==State::Launching||s==State::Saver||s==State::Fallback; }
struct Node { Time last=0,generation=0; State state=State::Desktop; bool manual=false; Time began=0;bool sticky=false;int presentation=-2;bool powerRequested=false; };
struct InputObservation {std::set<std::string> targets;bool certain=false;};
InputObservation AttributeInput(bool keyboard,const std::string& cursor,const std::string& foreground,unsigned age) {
    InputObservation observation;if(!cursor.empty()) observation.targets.insert(cursor);
    if(keyboard&&!foreground.empty()) observation.targets.insert(foreground);
    observation.certain=!cursor.empty()&&(!keyboard||!foreground.empty())&&age<=250;return observation;
}
struct Media { Time at=0; bool valid=false,any=false,ambiguous=false; std::set<std::string> monitors; };
bool AudioBlocks(bool active,bool includeMuted,bool sessionMute,bool endpointMute,float peak,float volume,float endpointVolume) {
    return active && (includeMuted||(!sessionMute&&!endpointMute&&peak>0.0001f&&volume>0.0001f&&endpointVolume>0.0001f));
}
bool DisplayRequestBlocks(bool includeMuted,bool ownedSaverPresent,bool requested) { return includeMuted&&!ownedSaverPresent&&requested; }
struct MediaGrace {
    Media previous;
    Media Apply(Media current,int poll) {
        if(current.valid&&current.any) previous=current;
        else if(current.valid&&!current.any&&previous.any&&current.at>=previous.at&&current.at-previous.at<=static_cast<Time>(std::max(2000,poll*2))) {
            auto at=current.at; current=previous; current.at=at;
        } return current;
    }
};
// A responsive child is still only a structural health observation, never
// evidence of animation. Three consecutive one-second failures avoid reacting
// to one busy frame; startup has a separate five-second deadline.
struct PreviewHealth {
    Time began=0; bool ready=false; unsigned misses=0;
    int Sample(Time now,bool exists,bool responsive) {
        if(!ready&&now>=began&&now-began>=5000) return 2;
        if(exists&&responsive) {bool first=!ready;ready=true;misses=0;return first?1:0;}
        return ready&&++misses>=3?2:0;
    }
};
bool PowerDue(const Preference& p,State state,Time began,Time now) {
    return p.hardware&&p.powerAfter>0&&Running(state)&&now>=began&&now-began>=static_cast<Time>(p.powerAfter)*1000;
}
struct PowerDeadline {
    Time began=0,cancellation=0;bool recovering=false,off=false;
    int Sample(Time now,bool stop,bool acknowledged) {
        off=off||acknowledged;
        if(!recovering&&(stop||(!off&&now>=began&&now-began>=5000))){recovering=true;cancellation=now;return 1;}
        return recovering&&now>=cancellation&&now-cancellation>=5000?2:0;
    }
};
struct Controller {
    Config config; std::map<std::string,Node> nodes; Time serial=0; bool paused=false,blocked=false;
    Preference spanPreference;
    std::set<std::string> fullscreen;
    void Topology(const std::vector<std::string>& ids,Time now) {
        nodes.clear(); for(auto& id:ids) nodes[id]={now,++serial,State::Desktop,false};
    }
    Preference Pref(const std::string& id) const {
        if(id=="@span")return spanPreference;
        auto it=config.monitors.find(id); return it==config.monitors.end()?Preference{}:it->second;
    }
    void Reset(Time now) { for(auto& [id,n]:nodes) { (void)id; n={now,++serial,State::Desktop,false}; } }
    void Input(Time now,const std::set<std::string>& targets,bool certain,Time eventAt=UINT64_MAX) {
        for(auto& [id,n]:nodes) {
            auto p=Pref(id);bool local=p.input<0?config.perInput:p.input!=0;
            if(!n.sticky&&(!n.manual||eventAt>n.last)&&(!local||!certain||targets.contains(id)||id=="@span")) n={now,++serial,State::Desktop,false};
        }
    }
    void Manual(const std::string& id,Time now,bool sticky=false,int presentation=-2) {
        auto it=nodes.find(id); if(it==nodes.end()||!Pref(id).enabled||paused||blocked) return;
        int saver=presentation==-2?Pref(id).saver:presentation;
        auto& n=it->second; n={now,++serial,saver<0?State::Black:State::Launching,true,now,sticky,saver};
    }
    bool Suppress(const std::string& id,const Media& m,Time now) const {
        auto p=Pref(id);if(p.fullscreen&&fullscreen.contains(id)) return true;
        if(!(p.media<0?config.media:p.media!=0)) return false;
        if(!m.valid||now<m.at||now-m.at>static_cast<Time>(std::max(2000,config.poll*2))) return true;
        return m.any && (!config.perMedia||m.ambiguous||m.monitors.contains(id));
    }
    void Tick(Time now,const Media& m) {
        bool spanning=nodes.contains("@span")&&Running(nodes.at("@span").state);
        for(auto& [id,n]:nodes) {
            auto p=Pref(id);
            if(spanning&&id!="@span") {n.last=now;n.state=State::Desktop;continue;}
            if(!p.enabled||paused||blocked) { if(Running(n.state)) n.generation=++serial; n.state=p.enabled?State::Desktop:State::Disabled; n.manual=false; n.last=now; continue; }
            if(Running(n.state)&&n.state!=State::Black&&now>=n.began&&
               ((p.blackAfter>0&&now-n.began>=static_cast<Time>(p.blackAfter)*1000)||
                (p.hardware&&p.powerAfter>0&&now-n.began>=static_cast<Time>(p.powerAfter)*1000))) {
                n.state=State::Black;n.presentation=-1;n.generation=++serial;
            }
            if(n.manual) continue;
            if(!config.automatic) { n.state=State::Desktop; continue; }
            if(Suppress(id,m,now)) { if(Running(n.state)) n.generation=++serial; n.state=State::Suppressed; n.last=now; continue; }
            if(now<n.last) { n.last=now; continue; } // defensive against injected clock regression
            if(now-n.last>=static_cast<Time>(p.timeout?p.timeout:config.timeout)*1000 && !Running(n.state)) { n.generation=++serial; n.state=p.saver<0?State::Black:State::Launching;n.began=now;n.presentation=p.saver; }
            else if(n.state==State::Suppressed) n.state=State::Desktop;
        }
    }
    bool Result(const std::string& id,Time generation,bool healthy) {
        auto it=nodes.find(id); if(it==nodes.end()||it->second.generation!=generation||!Running(it->second.state)) return false;
        if(healthy&&it->second.state==State::Fallback) return false;
        it->second.state=healthy?State::Saver:State::Fallback; return true;
    }
    bool Any() const { for(auto& [id,n]:nodes) { (void)id; if(Running(n.state)) return true; } return false; }
};
// Deliberate importer: parse into a copy, preserve the source, retain unknown
// display preferences. Numeric monitor aliases resolve only against this snapshot.
bool Import(const std::string& text,const std::vector<std::pair<std::string,std::string>>& displays,
            Config& c,int& ignored,std::string& error) {
    if(text.size()>262144) { error="Legacy file exceeds 256 KiB"; return false; }
    Config next=c; std::istringstream in(text); std::string line; int recognized=0; ignored=0;
    while(std::getline(in,line)) {
        line=Trim(line.substr(0,line.find(';'))); if(line.empty()||line[0]=='#'||line[0]=='[') continue;
        auto e=line.find('='); if(e==std::string::npos) { error="Malformed legacy line"; return false; }
        auto k=Trim(line.substr(0,e)),v=Trim(line.substr(e+1)); int n;
        bool known=k=="idleTimeout"||k=="checkInterval"||k=="pixelShiftCompensation"||k=="startupEnabled"||k=="debugMode"||k=="perMonitorInputDetection"||k=="perMonitorMediaDetection"||k=="blockOnMutedMedia"||k=="mediaDetectionEnabled"||k=="audioDetectionEnabled"||k.starts_with("monitor");
        if(!known) { ++ignored; continue; }
        if(!Number(v,n)) { error="Invalid legacy integer"; return false; }
        if(k=="idleTimeout") next.timeout=n; else if(k=="checkInterval") next.poll=n;
        else if(k=="pixelShiftCompensation") next.padding=n; else if(k=="startupEnabled") next.automatic=n!=0;
        else if(k=="debugMode") next.debug=n!=0; else if(k=="perMonitorInputDetection") next.perInput=n!=0;
        else if(k=="perMonitorMediaDetection") next.perMedia=n!=0; else if(k=="blockOnMutedMedia") next.muted=n!=0;
        else if(k=="mediaDetectionEnabled"||k=="audioDetectionEnabled") next.media=n!=0;
        else {
            std::string id; int index;
            if(k.starts_with("monitorEnabled_")) {
                id=Canonical(k.substr(15)); for(auto& [stable,alias]:displays) if(id==Canonical(alias)||id==Canonical(stable)) { id=Canonical(stable); break; }
            } else if(Number(k.substr(7),index)&&index>=0&&index<static_cast<int>(displays.size())) id=displays[index].first;
            else { ++ignored; continue; }
            if(id.empty()) { error="Empty legacy monitor identity"; return false; }
            next.monitors[id].enabled=n!=0;
        }
        ++recognized;
    }
    if(!recognized) { error="No recognized legacy settings"; return false; }
    Validate(next); c=std::move(next); return true;
}
} // namespace aegis

#ifndef AEGIS_POLICY_ONLY
#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>
#include <commdlg.h>
#include <wtsapi32.h>
#include <mmdeviceapi.h>
#include <audiopolicy.h>
#include <endpointvolume.h>
#include <powrprof.h>
#include <dwmapi.h>
#include <physicalmonitorenumerationapi.h>
#include <lowlevelmonitorconfigurationapi.h>
#include <gdiplus.h>

namespace aegis {
// Installed MinGW exposes only the meter forward declaration. This minimal
// ABI view uses the documented first method after IUnknown; no SDK code vendored.
struct MeterPeak : IUnknown { virtual HRESULT STDMETHODCALLTYPE GetPeakValue(float*)=0; };
constexpr GUID meterIID={0xc02216f6,0x8c67,0x4b5b,{0x9d,0x00,0xd0,0x08,0xe7,0x3e,0x00,0x64}};
// Compatibility identifiers intentionally survive the Liminal branding change.
constexpr wchar_t kClass[]=L"OLED-Aegis-V1-Host",kEditor[]=L"OLED-Aegis-V1-Settings",kOptions[]=L"OLED-Aegis-V1-SaverOptions";
#ifdef AEGIS_HARNESS
const std::wstring testStopName=L"Local\\OLED-Aegis-Test-"+std::to_wstring(GetCurrentProcessId());
const wchar_t* kStopName=testStopName.c_str();
#else
constexpr wchar_t kStopName[]=L"Local\\OLED-Aegis-V1-Emergency";
#endif
constexpr UINT kTray=WM_APP+1,kReload=WM_APP+2,kQuit=WM_APP+3;
constexpr const wchar_t* savers[]={L"Bubbles.scr",L"Mystify.scr",L"Ribbons.scr",L"ssText3d.scr",L"PhotoScreensaver.scr",L"scrnsave.scr"};
struct Handle {
    HANDLE value{}; Handle()=default; explicit Handle(HANDLE h):value(h==INVALID_HANDLE_VALUE?nullptr:h) {}
    ~Handle() { if(value) CloseHandle(value); }
    Handle(const Handle&)=delete; Handle& operator=(const Handle&)=delete;
    operator HANDLE() const { return value; }
};
template<class T> struct Com {
    T* p{}; ~Com(){if(p)p->Release();} T** out(){return &p;} T* operator->()const{return p;}
};
std::wstring Wide(const std::string& s) {
    int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,s.data(),static_cast<int>(s.size()),nullptr,0);
    std::wstring w(n,L'\0'); if(n) MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,s.data(),static_cast<int>(s.size()),w.data(),n); return w;
}
std::string Utf8(const std::wstring& s) {
    int n=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,s.data(),static_cast<int>(s.size()),nullptr,0,nullptr,nullptr);
    std::string b(n,'\0'); if(n) WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,s.data(),static_cast<int>(s.size()),b.data(),n,nullptr,nullptr); return b;
}
std::wstring Extended(const std::wstring& path) {
    if(path.empty()||path.size()>32000||path.find(L'\0')!=std::wstring::npos) return {};
    if(path.starts_with(L"\\\\?\\")) return path;
    if(path.starts_with(L"\\\\")) return L"\\\\?\\UNC\\"+path.substr(2);
    if(path.size()<3||path[1]!=L':'||path[2]!=L'\\') return {};
    return L"\\\\?\\"+path;
}
bool ReadFileText(const std::wstring& path,std::string& text,DWORD& error) {
    auto p=Extended(path); if(p.empty()) { error=ERROR_BAD_PATHNAME; return false; }
    Handle file(CreateFileW(p.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr));
    if(!file) { error=GetLastError(); return false; } LARGE_INTEGER size{};
    if(!GetFileSizeEx(file,&size)||size.QuadPart>262144||size.QuadPart<0) { error=ERROR_FILE_TOO_LARGE; return false; }
    text.resize(static_cast<size_t>(size.QuadPart)); DWORD got=0;
    if(!ReadFile(file,text.data(),static_cast<DWORD>(text.size()),&got,nullptr)||got!=text.size()) { error=ERROR_READ_FAULT; return false; }
    if(text.starts_with("\xef\xbb\xbf")) text.erase(0,3);
    if(!text.empty()&&Wide(text).empty()) { error=ERROR_NO_UNICODE_TRANSLATION; return false; }
    if(text.find('\0')!=std::string::npos) { error=ERROR_INVALID_DATA; return false; } return true;
}
// Same-directory replacement. Failure never commits live state. A failed final
// rename leaves the old file intact; stale private temp files are removed.
bool WriteFileText(const std::wstring& path,const std::string& text,DWORD& error) {
    auto p=Extended(path); if(p.empty()) { error=ERROR_BAD_PATHNAME; return false; }
    auto temp=p+L".tmp-"+std::to_wstring(GetCurrentProcessId());
    bool ok=false;
    { Handle f(CreateFileW(temp.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr));
      DWORD wrote=0;
      ok=f && WriteFile(f,text.data(),static_cast<DWORD>(text.size()),&wrote,nullptr)&&wrote==text.size()&&FlushFileBuffers(f);
      if(!ok) error=GetLastError(); }
    if(ok) { ok=!!MoveFileExW(temp.c_str(),p.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH); if(!ok) error=GetLastError(); }
    if(!ok) DeleteFileW(temp.c_str()); return ok;
}
std::wstring ConfigPath() {
    PWSTR folder=nullptr; if(FAILED(SHGetKnownFolderPath(FOLDERID_LocalAppData,0,nullptr,&folder))) return {};
    std::wstring dir=std::wstring(folder)+L"\\OLED_Aegis_Windhawk"; CoTaskMemFree(folder);
    auto extended=Extended(dir); if(extended.empty()) return {};
    if(!CreateDirectoryW(extended.c_str(),nullptr)&&GetLastError()!=ERROR_ALREADY_EXISTS) return {};
    return dir+L"\\settings-v1.ini";
}
std::wstring SaverPath(int index) {
    if(index<0||index>5) return {}; wchar_t path[32768];
    // Windhawk 1.7.3 hosts tools in a 32-bit process even on 64-bit Windows.
    // Sysnative selects the installed native savers without changing the
    // process/thread-wide WOW64 filesystem redirection state.
    BOOL wow64=FALSE; if(!IsWow64Process(GetCurrentProcess(),&wow64)) return {};
    if(wow64) { UINT n=GetWindowsDirectoryW(path,32768);
        return n&&n<32768?std::wstring(path)+L"\\Sysnative\\"+savers[index]:L""; }
    UINT n=GetSystemDirectoryW(path,32768);
    return n && n<32768?std::wstring(path)+L"\\"+savers[index]:L"";
}
bool Available(int index) { auto p=SaverPath(index); DWORD a=GetFileAttributesW(p.c_str()); return !p.empty()&&a!=INVALID_FILE_ATTRIBUTES&&!(a&FILE_ATTRIBUTE_DIRECTORY); }
struct Display { std::string id,alias; std::wstring label; HMONITOR handle{}; RECT rect{}; bool identified=false; };
std::vector<Display> displays;
Display spanningDisplay;
Controller controller;
std::wstring configPath;
std::atomic<HWND> ui{};
// BEGIN GENERATED FUJIN
// Fujin v0.1.0, commit c653620262ef68fa8d58504b6c47bb21aadc5aa5; regenerate with tools/sync-fujin.ps1.
/*
MIT License

Copyright (c) 2026 StarlightDaemon

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
*/
namespace fujin {
struct Palette { COLORREF base,surface,elevated,text,secondary,onAccent,border,strong,accent,hover,active,chrome,chromeText; };
constexpr Palette dark={RGB(0x1f,0x1f,0x1f),RGB(0x24,0x24,0x24),RGB(0x2e,0x2e,0x2e),RGB(0xc9,0xc9,0xc9),RGB(0xb8,0xb8,0xb8),RGB(0xff,0xff,0xff),RGB(0x3b,0x3b,0x3b),RGB(0x69,0x69,0x69),RGB(0x79,0x50,0xf2),RGB(0x70,0x48,0xe8),RGB(0x67,0x41,0xd9),RGB(0x24,0x24,0x24),RGB(0xc9,0xc9,0xc9)};
constexpr Palette light={RGB(0xde,0xe2,0xe6),RGB(0xff,0xff,0xff),RGB(0xf1,0xf3,0xf5),RGB(0x21,0x25,0x29),RGB(0x49,0x50,0x57),RGB(0xff,0xff,0xff),RGB(0xad,0xb5,0xbd),RGB(0x49,0x50,0x57),RGB(0x79,0x50,0xf2),RGB(0x70,0x48,0xe8),RGB(0x67,0x41,0xd9),RGB(0x34,0x3a,0x40),RGB(0xf8,0xf9,0xfa)};
constexpr int fontSize=12;
constexpr int spacing=16;
constexpr int radius=0;
constexpr wchar_t fontFamily[]=L"Verdana";
} // namespace fujin
// END GENERATED FUJIN
struct UiTheme {
    fujin::Palette colors=fujin::dark;
    bool highContrast=false,dark=true;
    HBRUSH base{},surface{};
    HICON small{},large{},active{};
} theme;
#ifdef AEGIS_HARNESS
int testTheme=-1; // 0 light, 1 dark, 2 high contrast; no Windows preference writes.
#endif
void FillColor(HDC dc,const RECT& rect,COLORREF color) {SetDCBrushColor(dc,color);FillRect(dc,&rect,static_cast<HBRUSH>(GetStockObject(DC_BRUSH)));}
void FrameColor(HDC dc,const RECT& rect,COLORREF color) {SetDCBrushColor(dc,color);FrameRect(dc,&rect,static_cast<HBRUSH>(GetStockObject(DC_BRUSH)));}
HICON AegisIcon(int size,bool active) {
    Gdiplus::Bitmap image(size,size,PixelFormat32bppARGB);Gdiplus::Graphics g(&image);
    g.Clear(Gdiplus::Color(0,0,0,0));g.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);g.ScaleTransform(size/32.f,size/32.f);
    auto c=theme.colors.accent;Gdiplus::SolidBrush accent(Gdiplus::Color(255,GetRValue(c),GetGValue(c),GetBValue(c)));
    auto ink=theme.colors.onAccent;Gdiplus::Pen outline(Gdiplus::Color(255,GetRValue(ink),GetGValue(ink),GetBValue(ink)),2.f);
    g.FillRectangle(&accent,2.f,4.f,27.f,19.f);g.DrawRectangle(&outline,2.f,4.f,27.f,19.f);
    g.DrawLine(&outline,12.f,27.f,21.f,27.f);g.DrawLine(&outline,16.f,23.f,16.f,27.f);
    Gdiplus::PointF shield[]={{16,8},{23,11},{22,17},{16,21},{10,17},{9,11}};
    auto base=theme.colors.base;Gdiplus::SolidBrush face(Gdiplus::Color(255,GetRValue(base),GetGValue(base),GetBValue(base)));g.FillPolygon(&face,shield,6);g.DrawPolygon(&outline,shield,6);
    if(active){g.DrawLine(&outline,12.f,14.f,15.f,17.f);g.DrawLine(&outline,15.f,17.f,20.f,12.f);}
    else g.DrawLine(&outline,16.f,12.f,16.f,17.f);
    HICON icon{};if(image.GetHICON(&icon)!=Gdiplus::Ok)return nullptr;return icon;
}
void ReadUiTheme() {
    HIGHCONTRASTW hc{};hc.cbSize=sizeof(hc);theme.highContrast=SystemParametersInfoW(SPI_GETHIGHCONTRAST,sizeof(hc),&hc,0)&&(hc.dwFlags&HCF_HIGHCONTRASTON);
    DWORD light=0,bytes=sizeof(light);RegGetValueW(HKEY_CURRENT_USER,L"Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize",L"AppsUseLightTheme",RRF_RT_REG_DWORD,nullptr,&light,&bytes);theme.dark=!light;
#ifdef AEGIS_HARNESS
    if(testTheme>=0){theme.highContrast=testTheme==2;theme.dark=testTheme==1;}
#endif
    theme.colors=theme.dark?fujin::dark:fujin::light;
    if(theme.highContrast){auto& p=theme.colors;p.base=GetSysColor(COLOR_WINDOW);p.surface=p.base;p.elevated=GetSysColor(COLOR_BTNFACE);p.text=GetSysColor(COLOR_WINDOWTEXT);p.secondary=GetSysColor(COLOR_GRAYTEXT);p.onAccent=GetSysColor(COLOR_HIGHLIGHTTEXT);p.border=p.strong=p.text;p.accent=p.hover=p.active=GetSysColor(COLOR_HIGHLIGHT);}
    if(theme.base)DeleteObject(theme.base);if(theme.surface)DeleteObject(theme.surface);
    theme.base=CreateSolidBrush(theme.colors.base);theme.surface=CreateSolidBrush(theme.colors.surface);
}
HFONT SettingsFont(int dpi) {
    NONCLIENTMETRICSW metrics{};metrics.cbSize=sizeof(metrics);
    if(!SystemParametersInfoForDpi(SPI_GETNONCLIENTMETRICS,sizeof(metrics),&metrics,0,dpi))return nullptr;
    if(!theme.highContrast){metrics.lfMessageFont.lfHeight=-MulDiv(fujin::fontSize,dpi,96);metrics.lfMessageFont.lfWeight=FW_NORMAL;wcscpy_s(metrics.lfMessageFont.lfFaceName,fujin::fontFamily);}
    return CreateFontIndirectW(&metrics.lfMessageFont);
}
void ThemeChrome(HWND w) {
    BOOL dark=theme.dark&&!theme.highContrast;DwmSetWindowAttribute(w,DWMWA_USE_IMMERSIVE_DARK_MODE,&dark,sizeof(dark));
    DWORD corner=fujin::radius==0?DWMWCP_DONOTROUND:DWMWCP_DEFAULT;DwmSetWindowAttribute(w,DWMWA_WINDOW_CORNER_PREFERENCE,&corner,sizeof(corner));
    COLORREF bg=theme.highContrast?DWMWA_COLOR_DEFAULT:theme.colors.chrome,fg=theme.highContrast?DWMWA_COLOR_DEFAULT:theme.colors.chromeText;
    DwmSetWindowAttribute(w,DWMWA_CAPTION_COLOR,&bg,sizeof(bg));DwmSetWindowAttribute(w,DWMWA_TEXT_COLOR,&fg,sizeof(fg));
    SendMessageW(w,WM_SETICON,ICON_SMALL,reinterpret_cast<LPARAM>(theme.small));SendMessageW(w,WM_SETICON,ICON_BIG,reinterpret_cast<LPARAM>(theme.large));
}
void PaintThemedControl(HWND w,HDC dc,int kind) {
    int saved=SaveDC(dc);RECT r{};GetClientRect(w,&r);auto& p=theme.colors;bool enabled=IsWindowEnabled(w);
    auto font=reinterpret_cast<HFONT>(SendMessageW(w,WM_GETFONT,0,0));if(font)SelectObject(dc,font);SetBkMode(dc,TRANSPARENT);
    int dpi=GetDpiForWindow(w),pad=MulDiv(fujin::spacing/2,dpi,96);bool focused=GetFocus()==w;bool hideFocus=SendMessageW(w,WM_QUERYUISTATE,0,0)&UISF_HIDEFOCUS;
    auto state=SendMessageW(w,BM_GETSTATE,0,0);bool down=kind!=3&&(state&BST_PUSHED);bool primary=GetDlgCtrlID(w)==130||GetDlgCtrlID(w)==220;
    bool hot=GetPropW(w,L"AegisHover")!=nullptr;COLORREF fg=enabled?p.text:p.secondary;
    std::wstring text;int length=GetWindowTextLengthW(w);text.resize(length+1);GetWindowTextW(w,text.data(),length+1);text.resize(length);
    RECT label=r;UINT flags=DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS;
    if(SendMessageW(w,WM_QUERYUISTATE,0,0)&UISF_HIDEACCEL)flags|=DT_HIDEPREFIX;
    if(kind==1){
        FillColor(dc,r,p.base);int side=MulDiv(fujin::spacing,dpi,96);RECT box{0,(r.bottom-side)/2,side,(r.bottom+side)/2};bool checked=SendMessageW(w,BM_GETCHECK,0,0)==BST_CHECKED;
        FillColor(dc,box,checked&&enabled?p.accent:p.surface);FrameColor(dc,box,hot&&enabled?p.accent:p.strong);
        if(checked){HPEN pen=CreatePen(PS_SOLID,std::max(1,MulDiv(2,dpi,96)),enabled?p.onAccent:p.secondary);auto old=SelectObject(dc,pen);MoveToEx(dc,box.left+side/4,box.top+side/2,nullptr);LineTo(dc,box.left+side*7/16,box.top+side*3/4);LineTo(dc,box.right-side/5,box.top+side/4);SelectObject(dc,old);DeleteObject(pen);}
        label.left=side+pad;
    }else{
        COLORREF bg=primary&&enabled?(down?p.active:hot?p.hover:p.accent):(down?p.surface:hot?p.elevated:p.surface);
        FillColor(dc,r,bg);FrameColor(dc,r,focused||hot?p.accent:p.border);if(primary&&enabled)fg=p.onAccent;label.left+=pad;label.right-=pad;
        if(kind==3){int arrow=MulDiv(24,dpi,96);label.right-=arrow;int x=r.right-arrow/2,y=r.bottom/2;POINT points[]={{x-4,y-2},{x+4,y-2},{x,y+3}};SetDCBrushColor(dc,fg);SelectObject(dc,GetStockObject(DC_BRUSH));SelectObject(dc,GetStockObject(NULL_PEN));Polygon(dc,points,3);flags|=DT_NOPREFIX;}
        else flags|=DT_CENTER;
    }
    SetTextColor(dc,fg);DrawTextW(dc,text.c_str(),static_cast<int>(text.size()),&label,flags);
    if(focused&&!hideFocus){RECT focus=kind==1?label:r;InflateRect(&focus,-3,-3);SetTextColor(dc,p.text);SetBkColor(dc,p.base);DrawFocusRect(dc,&focus);}
    RestoreDC(dc,saved);
}
LRESULT CALLBACK ThemeControlProc(HWND w,UINT msg,WPARAM wp,LPARAM lp) {
    auto original=reinterpret_cast<WNDPROC>(GetPropW(w,L"AegisOriginalProc"));int kind=static_cast<int>(reinterpret_cast<INT_PTR>(GetPropW(w,L"AegisKind")));
    if(msg==WM_NCDESTROY){SetWindowLongPtrW(w,GWLP_WNDPROC,reinterpret_cast<LONG_PTR>(original));RemovePropW(w,L"AegisHover");RemovePropW(w,L"AegisKind");RemovePropW(w,L"AegisOriginalProc");return CallWindowProcW(original,w,msg,wp,lp);}
    if(!theme.highContrast&&(msg==WM_PAINT||msg==WM_PRINTCLIENT)){
        PAINTSTRUCT ps{};HDC dc=msg==WM_PAINT?BeginPaint(w,&ps):reinterpret_cast<HDC>(wp);PaintThemedControl(w,dc,static_cast<int>(kind));if(msg==WM_PAINT)EndPaint(w,&ps);return 0;
    }
    if(msg==WM_MOUSEMOVE&&!GetPropW(w,L"AegisHover")){SetPropW(w,L"AegisHover",reinterpret_cast<HANDLE>(1));TRACKMOUSEEVENT track{sizeof(track),TME_LEAVE,w,0};TrackMouseEvent(&track);InvalidateRect(w,nullptr,FALSE);}
    if(msg==WM_MOUSELEAVE){RemovePropW(w,L"AegisHover");InvalidateRect(w,nullptr,FALSE);}
    auto result=CallWindowProcW(original,w,msg,wp,lp);
    if(msg==BM_SETCHECK||msg==BM_SETSTATE||msg==WM_ENABLE||msg==WM_SETFOCUS||msg==WM_KILLFOCUS||msg==WM_UPDATEUISTATE||msg==CB_SETCURSEL||msg==WM_SETTEXT)InvalidateRect(w,nullptr,FALSE);
    return result;
}
void ThemeControl(HWND w,const wchar_t* cls) {
    int kind=0;if(wcscmp(cls,L"BUTTON")==0)kind=(GetWindowLongPtrW(w,GWL_STYLE)&BS_TYPEMASK)==BS_AUTOCHECKBOX?1:2;
    else if(wcscmp(cls,L"COMBOBOX")==0)kind=3;
    if(!w||!kind)return;
    auto original=GetWindowLongPtrW(w,GWLP_WNDPROC);
    if(!SetPropW(w,L"AegisOriginalProc",reinterpret_cast<HANDLE>(original)))return;
    if(!SetPropW(w,L"AegisKind",reinterpret_cast<HANDLE>(static_cast<INT_PTR>(kind)))){RemovePropW(w,L"AegisOriginalProc");return;}
    SetLastError(0);if(!SetWindowLongPtrW(w,GWLP_WNDPROC,reinterpret_cast<LONG_PTR>(ThemeControlProc))&&GetLastError()){RemovePropW(w,L"AegisOriginalProc");RemovePropW(w,L"AegisKind");}
}
bool ThemeMessage(HWND w,UINT msg,WPARAM wp,LPARAM lp,LRESULT& result) {
    result=0;
    if(msg==WM_ERASEBKGND||msg==WM_PRINTCLIENT){RECT r{};GetClientRect(w,&r);FillRect(reinterpret_cast<HDC>(wp),&r,theme.base);result=1;return true;}
    if(msg==WM_CTLCOLORSTATIC||msg==WM_CTLCOLOREDIT||msg==WM_CTLCOLORLISTBOX||msg==WM_CTLCOLORBTN){
        if(theme.highContrast)return false;HDC dc=reinterpret_cast<HDC>(wp);bool surface=msg==WM_CTLCOLOREDIT||msg==WM_CTLCOLORLISTBOX;
        SetTextColor(dc,IsWindowEnabled(reinterpret_cast<HWND>(lp))?theme.colors.text:theme.colors.secondary);SetBkColor(dc,surface?theme.colors.surface:theme.colors.base);result=reinterpret_cast<LRESULT>(surface?theme.surface:theme.base);return true;
    }
    if(msg==WM_DRAWITEM){auto d=reinterpret_cast<DRAWITEMSTRUCT*>(lp);if(d->CtlType!=ODT_COMBOBOX)return false;
        int saved=SaveDC(d->hDC);bool selected=d->itemState&ODS_SELECTED;auto& p=theme.colors;FillColor(d->hDC,d->rcItem,selected?p.accent:p.surface);SetBkMode(d->hDC,TRANSPARENT);SetTextColor(d->hDC,selected?p.onAccent:p.text);
        auto font=SendMessageW(d->hwndItem,WM_GETFONT,0,0);if(font)SelectObject(d->hDC,reinterpret_cast<HFONT>(font));
        if(d->itemID!=static_cast<UINT>(-1)){int n=static_cast<int>(SendMessageW(d->hwndItem,CB_GETLBTEXTLEN,d->itemID,0));if(n>=0&&n<32768){std::wstring text(n+1,L'\0');SendMessageW(d->hwndItem,CB_GETLBTEXT,d->itemID,reinterpret_cast<LPARAM>(text.data()));RECT r=d->rcItem;r.left+=MulDiv(8,GetDpiForWindow(w),96);DrawTextW(d->hDC,text.c_str(),n,&r,DT_SINGLELINE|DT_VCENTER|DT_NOPREFIX|DT_END_ELLIPSIS);}}
        if((d->itemState&ODS_FOCUS)&&!(d->itemState&ODS_NOFOCUSRECT))DrawFocusRect(d->hDC,&d->rcItem);RestoreDC(d->hDC,saved);result=TRUE;return true;
    }
    if(msg==WM_MEASUREITEM){auto m=reinterpret_cast<MEASUREITEMSTRUCT*>(lp);if(m->CtlType==ODT_COMBOBOX){m->itemHeight=MulDiv(24,GetDpiForWindow(w),96);result=TRUE;return true;}}
    return false;
}

HWND editor{};
HFONT editorFont{};
HWND options{};HFONT optionsFont{};ULONG_PTR imagingToken{};
std::wstring hotkeyStatus;
HANDLE uiThread{},safetyThread{},mediaThread{},stopEvent{},readyEvent{},safetyReady{},singleton{};
std::atomic<bool> ready{},safetyOK{},unloading{},debug{},startupComplete{};
UINT taskbar{}; HPOWERNOTIFY powerNotification{};
bool trayPresent=false,locked=false,suspended=false,displayOff=false,topologyPending=false;
Time nextPoll=0,nextTray=0; DWORD lastInputStamp=0,rawStamp=0;
std::mutex observationLock;
Media observation; Config mediaConfig; std::vector<Display> mediaDisplays; uint64_t observationEpoch=0;
std::mutex registryLock; // Only handle publication/removal; NEVER held across launch/media queries.
std::map<HANDLE,HWND> ownedJobs;
std::set<HWND> ownedWindows;
std::atomic<unsigned> diagnostics{};
#ifdef AEGIS_HARNESS
int initFault=0;
std::atomic<DWORD> launchDelay{};
bool injectedObservations=false;
int trayFailures=0,configurationFailures=0;
#endif
void Note(const wchar_t* event,DWORD code=0) {
#ifdef AEGIS_HARNESS
    wprintf(L"%llu %ls code=%lu\n",GetTickCount64(),event,code); fflush(stdout);
#else
    if(debug && diagnostics.fetch_add(1)<1000) Wh_Log(L"%s: %lu",event,code);
#endif
}
void Notice(const wchar_t* text) {
    NOTIFYICONDATAW n{}; n.cbSize=sizeof(n); n.hWnd=ui; n.uID=1; n.uFlags=NIF_INFO;
    wcscpy_s(n.szInfoTitle,L"Liminal OLED Guard"); wcsncpy_s(n.szInfo,text,_TRUNCATE); Shell_NotifyIconW(NIM_MODIFY,&n);
}
BOOL CALLBACK EnumMonitor(HMONITOR m,HDC,LPRECT r,LPARAM data) {
    auto list=reinterpret_cast<std::vector<Display>*>(data); MONITORINFOEXW info{}; info.cbSize=sizeof(info);
    if(list->size()>=32||!GetMonitorInfoW(m,&info)) return TRUE;
    Display d; d.handle=m; d.rect=*r; d.alias=Utf8(info.szDevice); d.label=info.szDevice;
    list->push_back(d); return TRUE;
}
std::vector<Display> Catalog() {
    std::vector<Display> list; EnumDisplayMonitors(nullptr,nullptr,EnumMonitor,reinterpret_cast<LPARAM>(&list));
    // One logical source with multiple physical targets is a clone group. It is
    // deliberately disabled: independent physical presentation is impossible.
    std::map<std::string,std::vector<std::pair<std::string,std::wstring>>> identities;
    for(int retry=0;retry<3;++retry) {
        UINT32 pc=0,mc=0; if(GetDisplayConfigBufferSizes(QDC_ONLY_ACTIVE_PATHS,&pc,&mc)!=ERROR_SUCCESS||pc>256||mc>1024) break;
        std::vector<DISPLAYCONFIG_PATH_INFO> paths(pc); std::vector<DISPLAYCONFIG_MODE_INFO> modes(mc);
        LONG status=QueryDisplayConfig(QDC_ONLY_ACTIVE_PATHS,&pc,paths.data(),&mc,modes.data(),nullptr);
        if(status==ERROR_INSUFFICIENT_BUFFER) continue; if(status!=ERROR_SUCCESS) break;
        for(UINT32 i=0;i<pc;++i) {
            auto& p=paths[i]; DISPLAYCONFIG_SOURCE_DEVICE_NAME source{};
            source.header={DISPLAYCONFIG_DEVICE_INFO_GET_SOURCE_NAME,sizeof(source),p.sourceInfo.adapterId,p.sourceInfo.id};
            DISPLAYCONFIG_TARGET_DEVICE_NAME target{};
            target.header={DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_NAME,sizeof(target),p.targetInfo.adapterId,p.targetInfo.id};
            if(DisplayConfigGetDeviceInfo(&source.header)==ERROR_SUCCESS&&DisplayConfigGetDeviceInfo(&target.header)==ERROR_SUCCESS&&target.monitorDevicePath[0])
                identities[Utf8(source.viewGdiDeviceName)].push_back({Canonical(Utf8(target.monitorDevicePath)),target.monitorFriendlyDeviceName});
        } break;
    }
    std::map<std::string,int> count;
    for(auto& [alias,ids]:identities) { (void)alias; for(auto& [id,label]:ids) { (void)label; ++count[id]; } }
    for(auto& d:list) {
        auto& ids=identities[d.alias];
        if(ids.size()==1&&count[ids[0].first]==1) { d.id=ids[0].first; d.label+=L" — "+ids[0].second; d.identified=true; }
        else { d.id="unidentified:"+d.alias; d.label+=L" (unidentified or cloned; disabled)"; }
    } return list;
}

// Hardware control is isolated from UI/media/emergency threads. No DDC reads
// occur during catalog/startup. Only an opted-in exact unique target is touched.
std::wstring PowerMarker(const std::string& id) {
    uint64_t hash=1469598103934665603ULL;for(unsigned char c:id){hash^=c;hash*=1099511628211ULL;}
    return configPath+L".power-"+std::to_wstring(hash)+L".pending";
}
bool PowerPending(const std::string& id) {return GetFileAttributesW(Extended(PowerMarker(id)).c_str())!=INVALID_FILE_ATTRIBUTES;}
std::wstring PowerCancelName(const std::string& token){return L"Local\\OLED-Aegis-Power-Cancel-"+Wide(token);}
bool PowerTicket(const std::string& marker,const std::string& id,const std::string& token,bool wake) {
    auto prefix=id+"\n"+token+"\n";return wake?(marker==prefix+"changing"||marker==prefix+"off"):(marker==prefix+"probe");
}
int PowerChild(const std::string& id,bool wake,const std::string& token) {
    configPath=ConfigPath();if(configPath.empty())return 10;
    if(token.size()!=32||token.find_first_not_of("0123456789abcdef")!=std::string::npos)return 10;
    Handle cancelled(OpenEventW(SYNCHRONIZE,FALSE,PowerCancelName(token).c_str()));if(!cancelled)return 10;
    auto markerPath=PowerMarker(id);auto lockName=L"Local\\OLED-Aegis-DDC-"+markerPath.substr(configPath.size()+7);
    Handle mutex(CreateMutexW(nullptr,FALSE,lockName.c_str()));if(!mutex)return 10;
    DWORD acquired=WaitForSingleObject(mutex,0);if(acquired!=WAIT_OBJECT_0&&acquired!=WAIT_ABANDONED)return 10;
    struct Unlock {HANDLE mutex;~Unlock(){ReleaseMutex(mutex);}}unlock{mutex};
    std::string marker,text,error;DWORD code=0;
    if(!ReadFileText(markerPath,marker,code)||!PowerTicket(marker,id,token,wake))return 10;
    if(!wake&&WaitForSingleObject(cancelled,0)!=WAIT_TIMEOUT)return 10;
    if(!wake) {Config c;if(!ReadFileText(configPath,text,code)||!Parse(text,c,error)||!c.monitors.contains(id)||!c.monitors[id].hardware)return 10;}
    auto list=Catalog();auto found=std::find_if(list.begin(),list.end(),[&](const Display& d){return d.identified&&d.id==id;});
    if(found==list.end())return 10;
    DWORD count=0;if(!GetNumberOfPhysicalMonitorsFromHMONITOR(found->handle,&count)||count!=1)return 11;
    PHYSICAL_MONITOR physical{};if(!GetPhysicalMonitorsFromHMONITOR(found->handle,1,&physical))return 11;
    int result=11;
    if(wake) {if(WriteFileText(markerPath,id+"\n"+token+"\nwaking",code))result=SetVCPFeature(physical.hPhysicalMonitor,0xd6,0x01)?0:12;}
    else {
        MC_VCP_CODE_TYPE type{};DWORD current=0,maximum=0;
        // Avoid capabilities-string reads: some drivers/monitors mishandle them.
        // A D6 read does not prove that every power value is supported.
        if(GetVCPFeatureAndVCPFeatureReply(physical.hPhysicalMonitor,0xd6,&type,&current,&maximum)) {
            if(current!=0x01||WaitForSingleObject(cancelled,0)!=WAIT_TIMEOUT)result=10; // never take ownership of an already-off display
            else if(WriteFileText(markerPath,id+"\n"+token+"\nchanging",code)) {
                result=SetVCPFeature(physical.hPhysicalMonitor,0xd6,0x04)?0:12;
                if(result==0&&!WriteFileText(markerPath,id+"\n"+token+"\noff",code))result=12;
            }
        }
    }
    DestroyPhysicalMonitors(1,&physical);return result;
}
// One loaded helper owns the entire cycle, including wake during mod disable.
// The nonce-bound acknowledgement, not exit code alone, establishes completion.
template<class Cancel,class Action> int PowerCycle(const std::string& id,const std::string& token,Cancel cancelled,Action action) {
    DWORD error=0;std::string marker;const auto path=PowerMarker(id);const auto prefix=id+"\n"+token+"\n";
    if(!ReadFileText(path,marker,error)||!PowerTicket(marker,id,token,false))return 10;
    int result=action(false);
    bool readable=ReadFileText(path,marker,error);bool changed=result==0||(readable&&PowerTicket(marker,id,token,true));
    if(changed){if(result==0)while(!cancelled())Sleep(50);
        if(action(true)==0&&WriteFileText(path,prefix+"awake",error))return 0;
        WriteFileText(path,prefix+"fault",error);return 12;
    }
    if(readable&&PowerTicket(marker,id,token,false)&&(result==10||result==11)) {WriteFileText(path,prefix+"untouched",error);return result;}
    return 13;
}
int PowerGuardian(const std::string& id,const std::string& token) {
    configPath=ConfigPath();Handle cancelled(OpenEventW(SYNCHRONIZE,FALSE,PowerCancelName(token).c_str()));if(!cancelled)return 10;
    return PowerCycle(id,token,[&]{return WaitForSingleObject(cancelled,0)!=WAIT_TIMEOUT;},[&](bool wake){return PowerChild(id,wake,token);});
}
struct PowerTask {
    std::string id,token;Time generation=0;std::atomic<bool> cancel{},done{};
    std::atomic<int> status{}; // 0 pending; 1 off command accepted; 2 failed; 3 wake failed
    std::thread worker;
    int reported=0;
};
std::vector<std::unique_ptr<PowerTask>> powerTasks;
std::map<std::string,std::wstring> powerStatus;
#ifdef AEGIS_HARNESS
std::atomic<int> fakePowerOff{},fakePowerOn{},fakePowerResult{},fakePowerDelay{},fakePowerWakeResult{};
int fakePowerProcess=0;
#endif
int ExecutePowerProcess(PowerTask* task,HANDLE cancelled,const std::wstring& executable,std::wstring command) {
    const auto& id=task->id;
    Handle job(CreateJobObjectW(nullptr,nullptr));JOBOBJECT_EXTENDED_LIMIT_INFORMATION limit{};limit.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
    if(!job||!SetInformationJobObject(job,JobObjectExtendedLimitInformation,&limit,sizeof(limit)))return 11;
    STARTUPINFOW si{};si.cb=sizeof(si);si.dwFlags=STARTF_USESHOWWINDOW;si.wShowWindow=SW_HIDE;PROCESS_INFORMATION pi{};
    if(!CreateProcessW(executable.c_str(),command.data(),nullptr,nullptr,FALSE,CREATE_SUSPENDED|CREATE_NO_WINDOW,nullptr,nullptr,&si,&pi))return 11;
    Handle process(pi.hProcess),thread(pi.hThread);
    if(!AssignProcessToJobObject(job,process)){TerminateProcess(process,1);WaitForSingleObject(process,INFINITE);return 11;}
    if(ResumeThread(thread)==DWORD(-1)){TerminateJobObject(job,1);WaitForSingleObject(process,INFINITE);return 11;}
    PowerDeadline deadline{GetTickCount64()};bool off=false;
    while(WaitForSingleObject(process,50)==WAIT_TIMEOUT) {
        auto now=GetTickCount64();std::string marker;DWORD error=0;
        if(!off&&ReadFileText(PowerMarker(id),marker,error)&&marker==id+"\n"+task->token+"\noff"){off=true;task->status=1;}
        int action=deadline.Sample(now,task->cancel||WaitForSingleObject(stopEvent,0)!=WAIT_TIMEOUT,off);
        if(action==1)SetEvent(cancelled);
        if(action==2){TerminateJobObject(job,1);WaitForSingleObject(process,INFINITE);return 13;}
    }
    DWORD exit=1;GetExitCodeProcess(process,&exit);return static_cast<int>(exit);
}
int ExecutePower(PowerTask* task,HANDLE cancelled) {
    const auto& id=task->id;
#ifdef AEGIS_HARNESS
    if(fakePowerProcess){wchar_t path[32768]{};GetModuleFileNameW(nullptr,path,32768);return ExecutePowerProcess(task,cancelled,path,L"\""+std::wstring(path)+L"\" --power-helper "+Wide(Hex(id))+L" "+Wide(task->token)+L" "+std::to_wstring(fakePowerProcess));}
    return PowerCycle(id,task->token,[&]{return task->cancel||WaitForSingleObject(stopEvent,0)!=WAIT_TIMEOUT;},[&](bool wake){
        if(wake){++fakePowerOn;return int(fakePowerWakeResult);}
        ++fakePowerOff;if(fakePowerDelay)Sleep(fakePowerDelay);if(task->cancel||WaitForSingleObject(stopEvent,0)!=WAIT_TIMEOUT)return 10;
        DWORD code=0;int result=fakePowerResult;if(result!=10&&result!=11)WriteFileText(PowerMarker(id),id+"\n"+task->token+(result==0?"\noff":"\nchanging"),code);
        if(result==0)task->status=1;return result;
    });
#else
    wchar_t path[32768];DWORD size=GetModuleFileNameW(nullptr,path,32768);if(!size||size>=32768)return 11;
    return ExecutePowerProcess(task,cancelled,path,L"\""+std::wstring(path)+L"\" -tool-mod \""+WH_MOD_ID+L"\" -aegis-power "+Wide(Hex(id))+L" cycle "+Wide(task->token));
#endif
}
void PowerWorker(PowerTask* task) {
    const auto path=PowerMarker(task->id);DWORD error=0;
    GUID guid{};if(FAILED(CoCreateGuid(&guid))){task->status=2;task->done=true;return;}
    task->token=Hex(std::string(reinterpret_cast<char*>(&guid),sizeof(guid)));
    Handle cancelled(CreateEventW(nullptr,TRUE,FALSE,PowerCancelName(task->token).c_str()));
    if(!cancelled||task->cancel||WaitForSingleObject(stopEvent,0)!=WAIT_TIMEOUT||PowerPending(task->id)||!WriteFileText(path,task->id+"\n"+task->token+"\nprobe",error)){task->status=2;task->done=true;return;}
    int result=ExecutePower(task,cancelled);std::string marker,prefix=task->id+"\n"+task->token+"\n";bool readable=ReadFileText(path,marker,error);
    if(result==0&&readable&&marker==prefix+"awake")task->status=DeleteFileW(Extended(path).c_str())?4:3;
    else if(readable&&marker==prefix+"untouched"){task->status=2;DeleteFileW(Extended(path).c_str());}
    else {task->status=3;if(!readable)WriteFileText(path,prefix+"fault",error);}
    // An interrupted/timed-out probe stays quarantined; no automatic retries.
    task->done=true;
}
void StopPower() {for(auto& task:powerTasks)task->cancel=true;}
int StartPower(const Display& display,Time generation) {
    if(!display.identified||!controller.Pref(display.id).hardware||controller.blocked)return 0;
    for(auto& task:powerTasks)if(task->id==display.id)return -1; // busy, not consumed
    auto task=std::make_unique<PowerTask>();task->id=display.id;task->generation=generation;
    try{task->worker=std::thread(PowerWorker,task.get());}catch(...){return false;}
    powerTasks.push_back(std::move(task));return true;
}

// A run's worker exclusively owns its process and job. UI owns its HWND. The
// registry borrows the job only while published; emergency termination cannot
// race handle reuse. A stopped run is retained until worker completion.
struct Run {
    std::string id; Time generation{},began{}; HWND window{},preview{}; std::wstring path,args;
    std::atomic<bool> cancel{},abortChild{},done{}; std::atomic<int> status{}; // 0 launch, 1 heuristic child, 2 fallback
    std::thread worker; DWORD error=0; bool configuration=false,failureNotified=false,powerAttempted=false;
    Preference preference;int width=0,height=0;std::mutex frameLock;std::unique_ptr<Gdiplus::Bitmap> frame;
};
bool LocalFile(const std::wstring& path,const wchar_t* extension) {
    if(path.size()<4||path[1]!=L':'||path[2]!=L'\\'||path.size()>32760)return false;
    if(extension&&(path.size()<wcslen(extension)||_wcsicmp(path.c_str()+path.size()-wcslen(extension),extension)!=0))return false;
    auto attr=GetFileAttributesW(Extended(path).c_str());return attr!=INVALID_FILE_ATTRIBUTES&&!(attr&FILE_ATTRIBUTE_DIRECTORY);
}
void SlideFiles(const std::wstring& folder,bool recursive,std::vector<std::wstring>& files,Run* run,unsigned depth=0) {
    if(folder.size()<3||folder[1]!=L':'||folder[2]!=L'\\'||depth>16||files.size()>=2000||run->cancel)return;
    auto root=Extended(folder);DWORD attributes=GetFileAttributesW(root.c_str());if(attributes==INVALID_FILE_ATTRIBUTES||(attributes&FILE_ATTRIBUTE_REPARSE_POINT))return;
    WIN32_FIND_DATAW data{};HANDLE find=FindFirstFileW((root+L"\\*").c_str(),&data);if(find==INVALID_HANDLE_VALUE)return;
    do {
        if(run->cancel||WaitForSingleObject(stopEvent,0)!=WAIT_TIMEOUT||files.size()>=2000)break;
        if(data.cFileName[0]==L'.'&&(data.cFileName[1]==0||(data.cFileName[1]==L'.'&&data.cFileName[2]==0)))continue;
        if(data.dwFileAttributes&FILE_ATTRIBUTE_REPARSE_POINT)continue;
        auto path=folder+L"\\"+data.cFileName;
        if(data.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY){if(recursive)SlideFiles(path,recursive,files,run,depth+1);continue;}
        if(data.nFileSizeHigh||data.nFileSizeLow>32*1024*1024)continue;
        auto dot=path.find_last_of(L'.');if(dot==std::wstring::npos)continue;auto ext=path.substr(dot);
        if(_wcsicmp(ext.c_str(),L".jpg")==0||_wcsicmp(ext.c_str(),L".jpeg")==0||_wcsicmp(ext.c_str(),L".png")==0||_wcsicmp(ext.c_str(),L".bmp")==0||_wcsicmp(ext.c_str(),L".gif")==0)files.push_back(path);
    }while(FindNextFileW(find,&data));FindClose(find);
}
std::unique_ptr<Gdiplus::Bitmap> SlideFrame(const std::wstring& path,int width,int height,const Preference& p) {
    std::unique_ptr<Gdiplus::Image> source(Gdiplus::Image::FromFile(Extended(path).c_str(),FALSE));
    if(!source||source->GetLastStatus()!=Gdiplus::Ok||!source->GetWidth()||!source->GetHeight()||uint64_t(source->GetWidth())*source->GetHeight()>40000000)return {};
    double cap=std::min({1.0,4096.0/width,4096.0/height});width=std::max(1,int(width*cap));height=std::max(1,int(height*cap));
    auto frame=std::make_unique<Gdiplus::Bitmap>(width,height,PixelFormat32bppPARGB);if(frame->GetLastStatus()!=Gdiplus::Ok)return {};
    Gdiplus::Graphics graphics(frame.get());graphics.Clear(Gdiplus::Color(255,(p.background>>16)&255,(p.background>>8)&255,p.background&255));
    graphics.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
    double sw=source->GetWidth(),sh=source->GetHeight(),scale=std::min(width/sw,height/sh);
    if(p.placement==1)scale=std::max(width/sw,height/sh);if(p.placement==3||p.placement==4)scale=cap;if(p.placement==5)scale=std::min(cap,scale);
    float dw=p.placement==2?float(width):float(sw*scale),dh=p.placement==2?float(height):float(sh*scale);
    if(p.placement==4){Gdiplus::TextureBrush brush(source.get(),Gdiplus::WrapModeTile);brush.ScaleTransform(float(cap),float(cap));if(graphics.FillRectangle(&brush,0,0,width,height)!=Gdiplus::Ok)return {};}
    else if(graphics.DrawImage(source.get(),Gdiplus::RectF((width-dw)/2,(height-dh)/2,dw,dh))!=Gdiplus::Ok)return {};
    return frame;
}
void SlideWorker(Run* run) {
    try {
        std::vector<std::wstring> files;SlideFiles(Wide(run->preference.folder),run->preference.recursive,files,run);
        std::sort(files.begin(),files.end());std::mt19937 random(static_cast<unsigned>(GetTickCount64())^static_cast<unsigned>(reinterpret_cast<uintptr_t>(run)));
        if(run->preference.shuffle)std::shuffle(files.begin(),files.end(),random);
        size_t index=0,failures=0;
        while(!files.empty()&&!run->cancel&&!run->abortChild&&WaitForSingleObject(stopEvent,0)==WAIT_TIMEOUT) {
            auto frame=SlideFrame(files[index],run->width,run->height,run->preference);index=(index+1)%files.size();
            if(!frame){if(++failures>=files.size())break;continue;}failures=0;
            if(run->cancel||run->abortChild)break;
            {std::lock_guard lock(run->frameLock);run->frame=std::move(frame);}run->status=1;InvalidateRect(run->window,nullptr,FALSE);
            Time until=GetTickCount64()+static_cast<Time>(run->preference.slideSeconds)*1000;
            while(!run->cancel&&!run->abortChild&&GetTickCount64()<until&&WaitForSingleObject(stopEvent,50)==WAIT_TIMEOUT){}
            if(index==0&&run->preference.shuffle)std::shuffle(files.begin(),files.end(),random);
        }
    }catch(...){run->error=ERROR_NOT_ENOUGH_MEMORY;}
    run->status=2;run->done=true;
}
std::vector<std::unique_ptr<Run>> runs;
#ifdef AEGIS_HARNESS
// Only tests can substitute the owned fixture executable; product choices
// remain the six installed system paths. Main/UI thread exclusively owns this.
std::map<std::string,std::wstring> fixtureModes;
#endif
BOOL CALLBACK CloseOwned(HWND w,LPARAM lp) {
    HANDLE job=reinterpret_cast<HANDLE>(lp); DWORD pid=0; GetWindowThreadProcessId(w,&pid);
    Handle process(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid)); BOOL owned=FALSE;
    if(process && IsProcessInJob(process,job,&owned)&&owned) PostMessageW(w,WM_CLOSE,0,0); return TRUE;
}
struct ChildQuery { HANDLE job; HWND window=nullptr; };
BOOL CALLBACK FindOwnedChild(HWND w,LPARAM lp) {
    auto& q=*reinterpret_cast<ChildQuery*>(lp); DWORD pid=0; GetWindowThreadProcessId(w,&pid);
    Handle process(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid)); BOOL owned=FALSE;
    if(process&&IsProcessInJob(process,q.job,&owned)&&owned) {q.window=w;return FALSE;} return TRUE;
}
void RunWorker(Run* r) {
    Handle job(CreateJobObjectW(nullptr,nullptr)); JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits{};
    limits.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
    auto fail=[&](DWORD e) { r->error=e; r->status=2; Note(L"saver fallback",e); };
    if(!job||!SetInformationJobObject(job,JobObjectExtendedLimitInformation,&limits,sizeof(limits))) { fail(GetLastError()); r->done=true; return; }
    { std::lock_guard lock(registryLock); ownedJobs[job]=r->window; }
#ifdef AEGIS_HARNESS
    // A stalled launch simulation occurs after publication, with no registry lock.
    if(launchDelay) Sleep(launchDelay);
#endif
    PROCESS_INFORMATION pi{}; STARTUPINFOW si{}; si.cb=sizeof(si); si.dwFlags=STARTF_USESHOWWINDOW; si.wShowWindow=r->configuration?SW_SHOWNORMAL:SW_SHOWNOACTIVATE;
    std::wstring command=L"\""+r->path+L"\" "+r->args;
    if(r->cancel||r->abortChild||WaitForSingleObject(stopEvent,0)==WAIT_OBJECT_0) { }
    else if(!CreateProcessW(r->path.c_str(),command.data(),nullptr,nullptr,FALSE,CREATE_SUSPENDED,nullptr,nullptr,&si,&pi)) fail(GetLastError());
    else {
        Handle process(pi.hProcess),thread(pi.hThread);
        if(!AssignProcessToJobObject(job,process)) { fail(GetLastError()); TerminateProcess(process,1); WaitForSingleObject(process,2000); }
        else if(r->cancel||r->abortChild||WaitForSingleObject(stopEvent,0)==WAIT_OBJECT_0) TerminateJobObject(job,1);
        else if(ResumeThread(thread)==DWORD(-1)) { fail(GetLastError()); TerminateJobObject(job,1); }
        else {
            Note(L"owned process started",pi.dwProcessId);
            PreviewHealth health{r->began?r->began:GetTickCount64()};Time nextHealth=0;
            while(!r->cancel&&!r->abortChild&&WaitForSingleObject(stopEvent,50)==WAIT_TIMEOUT) {
                DWORD state=WaitForSingleObject(process,0);
                if(state!=WAIT_TIMEOUT) {
                    DWORD exitCode=0;
                    if(!r->configuration)fail(state==WAIT_OBJECT_0?ERROR_PROCESS_ABORTED:GetLastError());
                    else if(state!=WAIT_OBJECT_0||!GetExitCodeProcess(process,&exitCode)||exitCode!=0)fail(exitCode?exitCode:ERROR_PROCESS_ABORTED);
                    break;
                }
                auto now=GetTickCount64();
                if(!r->configuration&&now>=nextHealth) {
                    ChildQuery query{job}; EnumChildWindows(r->preview?r->preview:r->window,FindOwnedChild,reinterpret_cast<LPARAM>(&query));
                    DWORD_PTR ignored=0;
                    bool responsive=query.window&&SendMessageTimeoutW(query.window,WM_NULL,0,0,SMTO_BLOCK|SMTO_ABORTIFHUNG|SMTO_ERRORONEXIT,100,&ignored);
                    int result=health.Sample(now,query.window!=nullptr,responsive);
                    if(result==2) {fail(ERROR_TIMEOUT);break;}
                    if(result==1&&!r->abortChild) r->status=1;
                    nextHealth=now+(health.ready?1000:100);
                }
            }
            // Graceful close is posted, never sent synchronously to foreign UI.
            EnumWindows(CloseOwned,reinterpret_cast<LPARAM>(job.value));
            if(r->window) EnumChildWindows(r->window,CloseOwned,reinterpret_cast<LPARAM>(job.value));
            if(WaitForSingleObject(stopEvent,0)!=WAIT_OBJECT_0) WaitForSingleObject(process,750);
        }
        TerminateJobObject(job,0); // only this run's contained process tree
        if(WaitForSingleObject(process,2000)!=WAIT_OBJECT_0) Note(L"owned process exit wait expired");
    }
    { std::lock_guard lock(registryLock); ownedJobs.erase(job); }
    // job closes before done, so UI never destroys the parent while our child runs.
    if(job.value) { CloseHandle(job.value); job.value=nullptr; }
    r->done=true;
}

std::wstring ImageName(DWORD pid) {
    Handle process(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid));
    wchar_t path[32768]; DWORD n=32768;
    if(!process||!QueryFullProcessImageNameW(process,0,path,&n)) return {};
    std::wstring name(path,n); auto slash=name.find_last_of(L"\\/"); if(slash!=std::wstring::npos) name.erase(0,slash+1);
    CharLowerBuffW(name.data(),static_cast<DWORD>(name.size())); return name;
}
bool IsOwned(DWORD pid) {
    Handle process(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid)); if(!process) return false;
    // Duplicate handles under the registry lock; OS ownership queries occur after release.
    std::vector<HANDLE> jobs;
    { std::lock_guard lock(registryLock); for(auto& [job,window]:ownedJobs) {
        (void)window; HANDLE copy=nullptr;
        if(DuplicateHandle(GetCurrentProcess(),job,GetCurrentProcess(),&copy,0,FALSE,DUPLICATE_SAME_ACCESS)) jobs.push_back(copy);
    } }
    bool owned=false; for(auto job:jobs) { BOOL inJob=FALSE; if(IsProcessInJob(process,job,&inJob)&&inJob) owned=true; CloseHandle(job); }
    return owned;
}
struct WindowMatch { DWORD pid; std::wstring name; const std::vector<Display>* displays; std::set<std::string> ids; };
BOOL CALLBACK MatchWindow(HWND w,LPARAM lp) {
    auto& q=*reinterpret_cast<WindowMatch*>(lp);
    if(!IsWindowVisible(w)||IsIconic(w)||(GetWindowLongPtrW(w,GWL_EXSTYLE)&WS_EX_TOOLWINDOW)) return TRUE;
    DWORD cloaked=0;if(SUCCEEDED(DwmGetWindowAttribute(w,DWMWA_CLOAKED,&cloaked,sizeof(cloaked)))&&cloaked) return TRUE;
    DWORD pid=0; GetWindowThreadProcessId(w,&pid);
    if(pid!=q.pid && (q.name.empty()||ImageName(pid)!=q.name)) return TRUE;
    RECT r{}; if(FAILED(DwmGetWindowAttribute(w,DWMWA_EXTENDED_FRAME_BOUNDS,&r,sizeof(r)))&&!GetWindowRect(w,&r)) return TRUE;
    bool matched=false;
    for(auto& d:*q.displays) if(MediaOverlap({r.left,r.top,r.right,r.bottom},{d.rect.left,d.rect.top,d.rect.right,d.rect.bottom})) {q.ids.insert(d.id);matched=true;}
    if(!matched) {POINT center{r.left+(r.right-r.left)/2,r.top+(r.bottom-r.top)/2};for(auto& d:*q.displays) if(PtInRect(&d.rect,center)) q.ids.insert(d.id);}
    return TRUE;
}
Media ObserveEndpoint(IMMDevice* endpoint,const Config& c,const std::vector<Display>& list) {
    Media m;m.at=GetTickCount64();HRESULT hr;
    Com<IAudioSessionManager2> manager;
    if(FAILED(endpoint->Activate(__uuidof(IAudioSessionManager2),CLSCTX_ALL,nullptr,reinterpret_cast<void**>(manager.out())))) return m;
    Com<IAudioEndpointVolume> endpointVolume; BOOL deviceMuted=FALSE; float deviceLevel=1;
    if(FAILED(endpoint->Activate(__uuidof(IAudioEndpointVolume),CLSCTX_ALL,nullptr,reinterpret_cast<void**>(endpointVolume.out())))||
       FAILED(endpointVolume->GetMute(&deviceMuted))||FAILED(endpointVolume->GetMasterVolumeLevelScalar(&deviceLevel))) return m;
    Com<IAudioSessionEnumerator> sessions;
    if(FAILED(manager->GetSessionEnumerator(sessions.out()))) return m;
    int count=0; if(FAILED(sessions->GetCount(&count))||count>1024) return m;
    m.valid=true;
    for(int i=0;i<count;++i) {
        Com<IAudioSessionControl> session; Com<IAudioSessionControl2> details; Com<MeterPeak> meter; Com<ISimpleAudioVolume> volume;
        AudioSessionState state; DWORD pid=0; float peak=0,level=1; BOOL mute=FALSE;
        if(FAILED(sessions->GetSession(i,session.out()))||FAILED(session->GetState(&state))) { m.valid=false; continue; }
        if(state!=AudioSessionStateActive) continue;
        if(FAILED(session->QueryInterface(__uuidof(IAudioSessionControl2),reinterpret_cast<void**>(details.out())))) { m.valid=false; continue; }
        hr=details->GetProcessId(&pid); if(FAILED(hr)) { m.valid=false; continue; }
        bool ambiguous=hr!=S_OK; // includes AUDCLNT_S_NO_SINGLE_PROCESS
        if(pid==GetCurrentProcessId()||IsOwned(pid)) continue;
        if(!c.muted) {
            if(FAILED(session->QueryInterface(meterIID,reinterpret_cast<void**>(meter.out())))||
               FAILED(session->QueryInterface(__uuidof(ISimpleAudioVolume),reinterpret_cast<void**>(volume.out())))||
               FAILED(meter->GetPeakValue(&peak))||FAILED(volume->GetMute(&mute))||FAILED(volume->GetMasterVolume(&level))) { m.valid=false; continue; }
        }
        if(!AudioBlocks(true,c.muted,mute,deviceMuted,peak,level,deviceLevel)) continue;
        m.any=true;
        WindowMatch match{pid,ImageName(pid),&list,{}};
        EnumWindows(MatchWindow,reinterpret_cast<LPARAM>(&match));
        m.monitors.insert(match.ids.begin(),match.ids.end());
        m.ambiguous=m.ambiguous||ambiguous||match.ids.empty()||match.name.empty();
    }
    return m;
}
Media ObserveMedia(const Config& c,const std::vector<Display>& list) {
    Media m;m.at=GetTickCount64();bool owned=false;{std::lock_guard lock(registryLock);owned=!ownedJobs.empty();}
    if(c.muted&&!owned){ULONG state=0;if(CallNtPowerInformation(SystemExecutionState,nullptr,0,&state,sizeof(state))!=0)return m;
        if(DisplayRequestBlocks(c.muted,owned,(state&ES_DISPLAY_REQUIRED)!=0)){m.any=true;m.ambiguous=true;}}
    Com<IMMDeviceEnumerator> enumerator;Com<IMMDeviceCollection> endpoints;
    if(FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator),nullptr,CLSCTX_ALL,__uuidof(IMMDeviceEnumerator),reinterpret_cast<void**>(enumerator.out())))||FAILED(enumerator->EnumAudioEndpoints(eRender,DEVICE_STATE_ACTIVE,endpoints.out())))return m;
    UINT count=0;if(FAILED(endpoints->GetCount(&count))||count>64)return m;m.valid=true;
    for(UINT i=0;i<count;++i){Com<IMMDevice> endpoint;if(FAILED(endpoints->Item(i,endpoint.out()))){m.valid=false;continue;}
        auto sample=ObserveEndpoint(endpoint.p,c,list);m.valid=m.valid&&sample.valid;m.any=m.any||sample.any;m.ambiguous=m.ambiguous||sample.ambiguous;m.monitors.insert(sample.monitors.begin(),sample.monitors.end());}
    return m;
}
DWORD WINAPI MediaMain(void*) {
    HRESULT com=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    MediaGrace grace; uint64_t graceEpoch=0;
    while(WaitForSingleObject(stopEvent,0)==WAIT_TIMEOUT) {
        Config c; std::vector<Display> list; uint64_t epoch;
        { std::lock_guard lock(observationLock); c=mediaConfig; list=mediaDisplays; epoch=observationEpoch; }
        bool needed=c.media;for(auto& [id,p]:c.monitors){(void)id;if(p.enabled&&p.media==1)needed=true;}
        Media m; if(SUCCEEDED(com)&&needed) m=ObserveMedia(c,list); else if(!needed) { m.valid=true; m.at=GetTickCount64(); }
        if(epoch!=graceEpoch) {grace={};graceEpoch=epoch;}
        m=grace.Apply(m,c.poll);
        { std::lock_guard lock(observationLock); if(epoch==observationEpoch) observation=std::move(m); }
        if(WaitForSingleObject(stopEvent,c.poll)!=WAIT_TIMEOUT) break;
    }
    if(SUCCEEDED(com)) CoUninitialize(); return 0;
}
void InvalidateMedia() {
    std::lock_guard lock(observationLock); ++observationEpoch; observation={}; mediaConfig=controller.config; mediaDisplays=displays;
}
void StopRuns() {
    StopPower();
    for(auto& r:runs) { r->cancel=true; if(r->window) ShowWindowAsync(r->window,SW_HIDE); }
}
bool AddRun(const Display& d,Time generation,int saver,bool configuration=false) {
    if(configuration&&saver==7)return false;
    if(controller.blocked||WaitForSingleObject(stopEvent,0)!=WAIT_TIMEOUT) return false;
    if(runs.size()>=64) { Note(L"too many stopping sessions"); return false; }
    for(auto& r:runs) if(r->id==d.id&&!r->cancel) return false;
    auto r=std::make_unique<Run>(); r->id=d.id; r->generation=generation; r->configuration=configuration; r->began=GetTickCount64();
    r->preference=controller.Pref(d.id);r->width=d.rect.right-d.rect.left;r->height=d.rect.bottom-d.rect.top;
    if(d.id=="@span")r->preference=controller.Pref(spanningDisplay.alias);
    if(!configuration) {
        auto b=Padded({d.rect.left,d.rect.top,d.rect.right,d.rect.bottom},controller.config.padding);
        r->window=CreateWindowExW(WS_EX_TOPMOST|WS_EX_NOACTIVATE|WS_EX_TOOLWINDOW,kClass,L"Liminal OLED Guard",WS_POPUP|WS_CLIPCHILDREN,
            static_cast<int>(b.left),static_cast<int>(b.top),static_cast<int>(b.right-b.left),static_cast<int>(b.bottom-b.top),nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
        if(!r->window) return false;
        { std::lock_guard lock(registryLock); if(WaitForSingleObject(stopEvent,0)!=WAIT_TIMEOUT) {DestroyWindow(r->window);return false;} ownedWindows.insert(r->window); }
        if(saver>=0&&saver!=7) {
            // Padding is black; the saver gets the exact monitor-sized child.
            r->preview=CreateWindowExW(WS_EX_NOACTIVATE,kClass,L"",WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN,
                controller.config.padding,controller.config.padding,d.rect.right-d.rect.left,d.rect.bottom-d.rect.top,r->window,nullptr,GetModuleHandleW(nullptr),nullptr);
            if(!r->preview) { {std::lock_guard lock(registryLock);ownedWindows.erase(r->window);} DestroyWindow(r->window); return false; }
        }
#ifndef AEGIS_HARNESS
        { std::lock_guard lock(registryLock); if(WaitForSingleObject(stopEvent,0)==WAIT_TIMEOUT) ShowWindowAsync(r->window,SW_SHOWNOACTIVATE); }
#endif
    }
    if(saver>=0) {
        r->path=saver==6?Wide(r->preference.custom):SaverPath(saver);if(saver==6&&!LocalFile(r->path,L".scr"))r->path.clear();
        r->args=configuration?L"/c:"+std::to_wstring(reinterpret_cast<uintptr_t>(ui.load())):L"/p "+std::to_wstring(reinterpret_cast<uintptr_t>(r->preview));
#ifdef AEGIS_HARNESS
        if(auto it=fixtureModes.find(d.id);it!=fixtureModes.end()) {
            wchar_t exe[32768];DWORD size=GetModuleFileNameW(nullptr,exe,32768);
            if(size&&size<32768) {r->path=exe;r->args=it->second+L" "+std::to_wstring(reinterpret_cast<uintptr_t>(r->preview));}
        }
#endif
        try { r->worker=std::thread(saver==7?SlideWorker:RunWorker,r.get()); }
        catch(...) { if(r->window) { {std::lock_guard lock(registryLock);ownedWindows.erase(r->window);} DestroyWindow(r->window); } Note(L"worker creation failed"); return false; }
    } else r->done=true;
    runs.push_back(std::move(r)); return true;
}
void Reconcile() {
    for(auto it=powerTasks.begin();it!=powerTasks.end();) {
        auto& task=**it;auto n=controller.nodes.find(task.id);
        if(n==controller.nodes.end()||n->second.generation!=task.generation||!Running(n->second.state)||controller.blocked)task.cancel=true;
        int status=task.status;
        if(status!=task.reported) {
            task.reported=status;
            powerStatus[task.id]=status==1?L"Hardware off command accepted":status==2?L"Hardware unavailable; black fallback":status==3?L"Hardware wake failed; use monitor button":L"Hardware wake command accepted";
            if(status==2)Notice(L"Hardware power request failed or is quarantined. Black fallback remains. Check the monitor's DDC/CI setting; no automatic retry in this idle session.");
            if(status==3)Notice(L"Monitor wake failed. Use its physical power button. Hardware control remains quarantined until Reset hardware fault in Settings.");
        }
        if(task.done){if(task.worker.joinable())task.worker.join();it=powerTasks.erase(it);}else ++it;
    }
    for(auto it=runs.begin();it!=runs.end();) {
        auto& r=**it; auto n=controller.nodes.find(r.id);
        if(!r.configuration&&(n==controller.nodes.end()||n->second.generation!=r.generation||!Running(n->second.state))) r.cancel=true;
        if(r.cancel&&r.window) ShowWindowAsync(r.window,SW_HIDE);
        if(r.done&&(r.cancel||r.configuration)) {
            if(r.configuration&&!r.cancel&&r.status==2) {
                Notice(L"Saver configuration could not start. Check that the selected saver is installed and supports configuration.");
                Note(L"configuration failed",r.error);
#ifdef AEGIS_HARNESS
                ++configurationFailures;
#endif
            }
            if(r.worker.joinable()) r.worker.join(); if(r.window) { {std::lock_guard lock(registryLock);ownedWindows.erase(r.window);} DestroyWindow(r.window); }
            it=runs.erase(it); continue;
        }
        if(!r.cancel&&!r.configuration) {
            int status=r.status.exchange(0);
            if(status!=1&&n!=controller.nodes.end()&&n->second.state==State::Launching&&GetTickCount64()-r.began>=5000) {
                r.abortChild=true; status=2;
            }
            if(r.abortChild) status=2;
            if(status==2){std::lock_guard lock(r.frameLock);r.frame.reset();if(r.window)InvalidateRect(r.window,nullptr,FALSE);}
            if(status&&controller.Result(r.id,r.generation,status==1)&&status==2&&!r.failureNotified) {
                Notice(L"Saver exited, failed to start or stopped responding. Black fallback remains until activity or Stop; no automatic retry in this session.");
                r.failureNotified=true;
            }
            if(!r.powerAttempted&&r.done&&n!=controller.nodes.end()&&(n->second.powerRequested||PowerDue(controller.Pref(r.id),n->second.state,n->second.began,GetTickCount64()))) {
                auto display=std::find_if(displays.begin(),displays.end(),[&](const Display& d){return d.id==r.id;});
                if(display!=displays.end())r.powerAttempted=StartPower(*display,r.generation)>=0;
            }
        } ++it;
    }
    for(auto& d:displays) {
        auto& n=controller.nodes[d.id]; if(!Running(n.state)) continue;
        bool exists=false; for(auto& r:runs) if(r->id==d.id) { exists=true; break; }
        if(!exists&&!AddRun(d,n.generation,n.presentation==-2?controller.Pref(d.id).saver:n.presentation)) { n.state=State::Desktop; n.last=GetTickCount64(); Notice(L"Unable to create presentation; activation delayed."); }
    }
    auto span=controller.nodes.find("@span");
    if(span!=controller.nodes.end()) {
        if(!Running(span->second.state))controller.nodes.erase(span);
        else {bool exists=false;for(auto& r:runs)if(r->id=="@span")exists=true;
            if(!exists&&!AddRun(spanningDisplay,span->second.generation,span->second.presentation))controller.nodes.erase(span);}
    }
}
void Reset() { controller.Reset(GetTickCount64()); StopRuns(); nextPoll=0; }
void RefreshTopology() {
    Reset(); displays=Catalog(); std::vector<std::string> ids;
    for(auto& d:displays) ids.push_back(d.id);
    controller.Topology(ids,GetTickCount64()); InvalidateMedia(); topologyPending=false;
}
void SetBlocked() { controller.blocked=locked||suspended||displayOff||!trayPresent; Reset(); InvalidateMedia(); }
void Input(HRAWINPUT handle) {
#ifdef AEGIS_HARNESS
    if(injectedObservations) return;
#endif
    RAWINPUT input{}; UINT bytes=sizeof(input);
    if(GetRawInputData(handle,RID_INPUT,&input,&bytes,sizeof(RAWINPUTHEADER))==UINT(-1)) { controller.Input(GetTickCount64(),{},false); return; }
    bool keyboard=input.header.dwType==RIM_TYPEKEYBOARD;
    if(!keyboard&&input.header.dwType!=RIM_TYPEMOUSE) return;
    LASTINPUTINFO last{sizeof(last),0}; if(GetLastInputInfo(&last)) rawStamp=last.dwTime;
    POINT point{}; bool located=!!GetCursorPos(&point);std::string cursorId,focusId;
    HMONITOR cursor=located?MonitorFromPoint(point,MONITOR_DEFAULTTONULL):nullptr;
    HMONITOR focus=keyboard?MonitorFromWindow(GetForegroundWindow(),MONITOR_DEFAULTTONULL):nullptr;
    for(auto& d:displays) {if(d.handle==cursor)cursorId=d.id;if(d.handle==focus)focusId=d.id;}
    // Queue delay can change cursor/foreground attribution. Reset all when late.
    DWORD age=GetTickCount()-static_cast<DWORD>(GetMessageTime());
    auto attribution=AttributeInput(keyboard,cursorId,focusId,age);
    auto now=GetTickCount64();controller.Input(now,attribution.targets,attribution.certain,age>now?0:now-age); Reconcile();
}
void CheckInputFallback() {
    LASTINPUTINFO last{sizeof(last),0};
    if(!GetLastInputInfo(&last)) { controller.Input(GetTickCount64(),{},false); return; }
    if(last.dwTime!=lastInputStamp&&last.dwTime!=rawStamp) controller.Input(GetTickCount64(),{},false);
    lastInputStamp=last.dwTime;
}
void ObserveForeground() {
    static HWND previous=nullptr;HWND window=GetForegroundWindow();DWORD pid=0;GetWindowThreadProcessId(window,&pid);
    controller.fullscreen.clear();if(!window||pid==GetCurrentProcessId())return;
    HMONITOR monitor=MonitorFromWindow(window,MONITOR_DEFAULTTONULL);std::string id;
    RECT bounds{};bool valid=IsWindowVisible(window)&&!IsIconic(window)&&GetWindowRect(window,&bounds);
    for(auto& d:displays) if(d.handle==monitor) {
        id=d.id;if(valid&&bounds.left<=d.rect.left&&bounds.top<=d.rect.top&&bounds.right>=d.rect.right&&bounds.bottom>=d.rect.bottom)controller.fullscreen.insert(d.id);
    }
    if(window!=previous&&!id.empty())controller.Input(GetTickCount64(),{id},true);
    previous=window;
}
bool Tray(bool remove=false) {
#ifdef AEGIS_HARNESS
    if(remove)trayPresent=false;else if(trayFailures>0){--trayFailures;trayPresent=false;}else trayPresent=true;
    return remove||trayPresent; // test fake: never creates a desktop tray icon
#else
    NOTIFYICONDATAW n{}; n.cbSize=sizeof(n); n.hWnd=ui; n.uID=1; n.uFlags=NIF_MESSAGE|NIF_ICON|NIF_TIP;
    n.uCallbackMessage=kTray; n.hIcon=(controller.Any()?theme.active:theme.small);
    auto text=std::wstring(L"Liminal — ")+(controller.paused?L"paused":controller.Any()?L"presenting":controller.config.automatic?L"watching idle":L"manual only");
    wcsncpy_s(n.szTip,text.c_str(),_TRUNCATE);
    bool ok=!!Shell_NotifyIconW(remove?NIM_DELETE:trayPresent?NIM_MODIFY:NIM_ADD,&n);
    if(remove) trayPresent=false; else trayPresent=ok; return ok;
#endif
}
bool LegacyStartupPresent();
void RegisterControls() {
    UnregisterHotKey(ui,10);UnregisterHotKey(ui,11);hotkeyStatus.clear();
    if(!controller.config.hotkeys)return;
#ifdef AEGIS_HARNESS
    hotkeyStatus=L"Hotkeys simulated in test harness";
#else
    bool current=!!RegisterHotKey(ui,10,MOD_CONTROL|MOD_ALT|MOD_NOREPEAT,VK_F1+controller.config.currentKey-1);
    bool all=!!RegisterHotKey(ui,11,MOD_CONTROL|MOD_ALT|MOD_NOREPEAT,VK_F1+controller.config.allKey-1);
    hotkeyStatus=current&&all?L"Control hotkeys registered":L"Hotkey conflict: one or more controls unavailable";
    if(!current||!all)Notice(hotkeyStatus.c_str());
#endif
}
bool Save(Config next) {
    DWORD error=0;
    if(next.automatic&&LegacyStartupPresent()) {Notice(L"Disable legacy startup before enabling automatic mode.");return false;}
    std::string previous;
    if(ReadFileText(configPath,previous,error)&&(previous.starts_with("version=1\n")||previous.starts_with("version=1\r\n"))&&GetFileAttributesW(Extended(configPath+L".v1-backup").c_str())==INVALID_FILE_ATTRIBUTES) {
        if(!CopyFileW(Extended(configPath).c_str(),Extended(configPath+L".v1-backup").c_str(),TRUE)){Notice(L"Cannot preserve old settings for rollback; save cancelled.");return false;}
    }
    if(!Commit(controller.config,std::move(next),[&](const std::string& data){return WriteFileText(configPath,data,error);})) {
        Note(L"settings persistence failed",error); Notice(L"Settings could not be saved. Previous saved and active settings retained."); return false;
    }
    debug=controller.config.debug; diagnostics=0; Reset(); InvalidateMedia();RegisterControls(); return true;
}
void Reload() {
    std::string data,error; DWORD code=0; Config next;
    if(ReadFileText(configPath,data,code)&&Parse(data,next,error)) { if(LegacyStartupPresent()) next.automatic=false; controller.config=std::move(next); debug=controller.config.debug; Reset(); InvalidateMedia();RegisterControls(); }
    else Notice(L"Cannot reload settings. Existing active settings retained; inspect the versioned configuration.");
}
bool LegacyStartupPresent() {
    HKEY key{}; if(RegOpenKeyExW(HKEY_CURRENT_USER,L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",0,KEY_QUERY_VALUE,&key)!=ERROR_SUCCESS) return false;
    LSTATUS result=RegQueryValueExW(key,L"OLED Aegis",nullptr,nullptr,nullptr,nullptr); RegCloseKey(key); return result==ERROR_SUCCESS;
}
// UI controls edit a draft. Only Save invokes the canonical checked transaction.
Config draft; int selection=-1;
const wchar_t* StateLabel(State state) {
    switch(state){case State::Disabled:return L"disabled";case State::Suppressed:return L"kept awake";case State::Black:return L"black";
    case State::Launching:return L"starting saver";case State::Saver:return L"saver running";case State::Fallback:return L"black fallback";default:return L"desktop";}
}
void UpdateEditorStatus() {
    if(!editor||selection<0||selection>=static_cast<int>(displays.size()))return;
    auto& d=displays[selection];auto n=controller.nodes.find(d.id);std::wstring text=d.identified?L"State: ":L"Unidentified output; protection unavailable. ";
    if(n!=controller.nodes.end())text+=StateLabel(n->second.state);
    if(n!=controller.nodes.end()&&n->second.sticky)text+=L" (sticky)";
    if(powerStatus.contains(d.id))text+=L"\n"+powerStatus[d.id];else if(PowerPending(d.id))text+=L"\nHardware fault retained; confirm physical wake before reset.";
    SetDlgItemTextW(editor,147,text.c_str());
}
bool ValidMonitorNumbers() {
    if(selection<0)return true;
    for(int id:{140,143,145}){BOOL valid=false;GetDlgItemInt(editor,id,&valid,FALSE);if(!valid)return false;}return true;
}
void StoreMonitorDraft() {
    if(selection<0||selection>=static_cast<int>(displays.size())) return;
    auto& p=draft.monitors[displays[selection].id];
    p.enabled=IsDlgButtonChecked(editor,121)==BST_CHECKED;
    p.saver=static_cast<int>(SendDlgItemMessageW(editor,122,CB_GETCURSEL,0,0))-1;
    p.timeout=GetDlgItemInt(editor,140,nullptr,FALSE);p.input=static_cast<int>(SendDlgItemMessageW(editor,141,CB_GETCURSEL,0,0))-1;
    p.media=static_cast<int>(SendDlgItemMessageW(editor,142,CB_GETCURSEL,0,0))-1;p.blackAfter=GetDlgItemInt(editor,143,nullptr,FALSE);
    p.hardware=IsDlgButtonChecked(editor,144)==BST_CHECKED;p.powerAfter=GetDlgItemInt(editor,145,nullptr,FALSE);
    p.fullscreen=IsDlgButtonChecked(editor,146)==BST_CHECKED;
}
void LoadMonitorDraft() {
    selection=static_cast<int>(SendDlgItemMessageW(editor,120,CB_GETCURSEL,0,0));
    if(selection<0||selection>=static_cast<int>(displays.size())) return;
    auto& d=displays[selection]; auto it=draft.monitors.find(d.id); Preference p=it==draft.monitors.end()?Preference{}:it->second;
    CheckDlgButton(editor,121,p.enabled?BST_CHECKED:BST_UNCHECKED); EnableWindow(GetDlgItem(editor,121),d.identified);
    SendDlgItemMessageW(editor,122,CB_SETCURSEL,p.saver+1,0);
    SetDlgItemInt(editor,140,p.timeout,FALSE);SetDlgItemInt(editor,143,p.blackAfter,FALSE);SetDlgItemInt(editor,145,p.powerAfter,FALSE);
    SendDlgItemMessageW(editor,141,CB_SETCURSEL,p.input+1,0);SendDlgItemMessageW(editor,142,CB_SETCURSEL,p.media+1,0);
    CheckDlgButton(editor,144,p.hardware?BST_CHECKED:BST_UNCHECKED);CheckDlgButton(editor,146,p.fullscreen?BST_CHECKED:BST_UNCHECKED);
    EnableWindow(GetDlgItem(editor,144),d.identified);UpdateEditorStatus();
}
void PopulateEditor() {
    draft=controller.config;
    SetDlgItemInt(editor,101,draft.timeout,FALSE); SetDlgItemInt(editor,102,draft.poll,FALSE); SetDlgItemInt(editor,103,draft.padding,FALSE);
    bool flags[]={draft.automatic,draft.perInput,draft.media,draft.perMedia,draft.muted,draft.debug};
    for(int i=0;i<6;++i) CheckDlgButton(editor,110+i,flags[i]?BST_CHECKED:BST_UNCHECKED);
    SendDlgItemMessageW(editor,120,CB_RESETCONTENT,0,0);
    for(auto& d:displays) SendDlgItemMessageW(editor,120,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(d.label.c_str()));
    SendDlgItemMessageW(editor,120,CB_SETCURSEL,0,0); LoadMonitorDraft();
}
void ImportLegacy(HWND w) {
    wchar_t path[32768]{}; OPENFILENAMEW ofn{}; ofn.lStructSize=sizeof(ofn); ofn.hwndOwner=w;
    ofn.lpstrFilter=L"Legacy INI\0*.ini\0All files\0*.*\0"; ofn.lpstrFile=path; ofn.nMaxFile=32768;
    ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR; ofn.lpstrTitle=L"Import legacy OLED Aegis INI (original remains unchanged)";
    if(!GetOpenFileNameW(&ofn)) return;
    std::string text,error; DWORD code=0; int ignored=0; Config next=controller.config;
    std::vector<std::pair<std::string,std::string>> aliases;
    for(auto& d:displays) aliases.push_back({d.id,d.alias});
    if(!ReadFileText(path,text,code)||!Import(text,aliases,next,ignored,error)) { MessageBoxW(w,L"Legacy file could not be read or validated. No changes made.",L"Import failed",MB_OK|MB_ICONERROR); return; }
    if(LegacyStartupPresent()) next.automatic=false;
    if(Save(next)) {
        PopulateEditor(); auto message=L"Import saved; original INI unchanged. Ignored keys: "+std::to_wstring(ignored)+
            L".\nOld numeric/display-name aliases use the current display order.\nIf standalone startup exists, automatic activation stays off. Disable the legacy app's startup and exit it before enabling this edition. Windhawk startup is managed separately.";
        MessageBoxW(w,message.c_str(),L"Import complete",MB_OK);
    }
}
std::wstring ControlText(HWND w,int id) {wchar_t text[4096]{};GetDlgItemTextW(w,id,text,4096);return text;}
struct SettingsControl {HWND window;int x,y,width,height;};
struct SettingsLayout {int dpi=96;std::vector<SettingsControl> controls;};
SettingsLayout editorLayout,optionsLayout;
void LayoutSettings(HWND w,SettingsLayout& layout,int height,int& position) {
    RECT client{};GetClientRect(w,&client);SCROLLINFO info{};info.cbSize=sizeof(info);info.fMask=SIF_RANGE|SIF_PAGE|SIF_POS;
    info.nMax=MulDiv(height,layout.dpi,96);info.nPage=std::max<LONG>(0,client.bottom);info.nPos=position;SetScrollInfo(w,SB_VERT,&info,TRUE);
    info.fMask=SIF_POS;GetScrollInfo(w,SB_VERT,&info);position=info.nPos;
    for(auto& c:layout.controls){
        wchar_t cls[32]{};GetClassNameW(c.window,cls,32);if(wcscmp(cls,L"ComboBox")==0){SendMessageW(c.window,CB_SETITEMHEIGHT,0,MulDiv(24,layout.dpi,96));SendMessageW(c.window,CB_SETITEMHEIGHT,static_cast<WPARAM>(-1),MulDiv(24,layout.dpi,96));}
        SetWindowPos(c.window,nullptr,MulDiv(c.x,layout.dpi,96),MulDiv(c.y,layout.dpi,96)-position,
        MulDiv(c.width,layout.dpi,96),MulDiv(c.height,layout.dpi,96),SWP_NOZORDER|SWP_NOACTIVATE);
    }
}
void RefreshSettingsTheme() {
    ReadUiTheme();
    for(auto window:{editor,options})if(window){
        auto& layout=window==editor?editorLayout:optionsLayout;auto& font=window==editor?editorFont:optionsFont;
        HFONT replacement=SettingsFont(layout.dpi);if(replacement){for(auto& c:layout.controls)SendMessageW(c.window,WM_SETFONT,reinterpret_cast<WPARAM>(replacement),FALSE);if(font)DeleteObject(font);font=replacement;}
        ThemeChrome(window);RedrawWindow(window,nullptr,nullptr,RDW_INVALIDATE|RDW_ERASE|RDW_ALLCHILDREN);
    }
}
void SettingsDpiChanged(HWND w,WPARAM wp,LPARAM lp,SettingsLayout& layout,HFONT& font,int height,int& position) {
    int dpi=HIWORD(wp);if(dpi<=0||!lp)return;
    position=MulDiv(position,dpi,layout.dpi);layout.dpi=dpi;
    HFONT replacement=SettingsFont(dpi);
    if(replacement){for(auto& c:layout.controls)SendMessageW(c.window,WM_SETFONT,reinterpret_cast<WPARAM>(replacement),TRUE);if(font)DeleteObject(font);font=replacement;}
    RECT bounds=*reinterpret_cast<const RECT*>(lp);MONITORINFO monitor{};monitor.cbSize=sizeof(monitor);
    if(GetMonitorInfoW(MonitorFromRect(&bounds,MONITOR_DEFAULTTONEAREST),&monitor)) {
        int available=monitor.rcWork.bottom-monitor.rcWork.top;
        if(bounds.bottom-bounds.top>available){bounds.top=monitor.rcWork.top;bounds.bottom=monitor.rcWork.bottom;}
    }
    SetWindowPos(w,nullptr,bounds.left,bounds.top,bounds.right-bounds.left,bounds.bottom-bounds.top,SWP_NOZORDER|SWP_NOACTIVATE);
    LayoutSettings(w,layout,height,position);RedrawWindow(w,nullptr,nullptr,RDW_INVALIDATE|RDW_ERASE|RDW_ALLCHILDREN);
}
bool ScrollSettings(HWND w,UINT msg,WPARAM wp,LPARAM lp,int height,int& position,SettingsLayout& layout) {
    (void)lp;
    if(msg==WM_SIZE){LayoutSettings(w,layout,height,position);return true;}
    if(msg!=WM_VSCROLL&&msg!=WM_MOUSEWHEEL)return false;
    SCROLLINFO info{};info.cbSize=sizeof(info);info.fMask=SIF_ALL;GetScrollInfo(w,SB_VERT,&info);int pos=info.nPos;
    if(msg==WM_MOUSEWHEEL)pos-=GET_WHEEL_DELTA_WPARAM(wp)/WHEEL_DELTA*64;
    else switch(LOWORD(wp)){case SB_LINEUP:pos-=32;break;case SB_LINEDOWN:pos+=32;break;case SB_PAGEUP:pos-=info.nPage;break;case SB_PAGEDOWN:pos+=info.nPage;break;case SB_THUMBTRACK:pos=info.nTrackPos;break;}
    info.fMask=SIF_POS;info.nPos=pos;SetScrollInfo(w,SB_VERT,&info,TRUE);GetScrollInfo(w,SB_VERT,&info);ScrollWindowEx(w,0,position-info.nPos,nullptr,nullptr,nullptr,nullptr,SW_SCROLLCHILDREN|SW_INVALIDATE|SW_ERASE);position=info.nPos;return true;
}
void FitSettings(HWND w,int width,int height) {
    MONITORINFO monitor{};monitor.cbSize=sizeof(monitor);GetMonitorInfoW(MonitorFromWindow(w,MONITOR_DEFAULTTONEAREST),&monitor);int dpi=GetDpiForWindow(w);
    SetWindowPos(w,nullptr,monitor.rcWork.left,monitor.rcWork.top,MulDiv(width,dpi,96),std::min<int>(MulDiv(height,dpi,96),monitor.rcWork.bottom-monitor.rcWork.top),SWP_NOZORDER|SWP_NOACTIVATE);
}
int optionsScroll=0;
LRESULT CALLBACK OptionsProc(HWND w,UINT msg,WPARAM wp,LPARAM lp) {
    LRESULT themed{};if(ThemeMessage(w,msg,wp,lp,themed))return themed;
    if(ScrollSettings(w,msg,wp,lp,576,optionsScroll,optionsLayout))return 0;
    if(msg==WM_COMMAND) {
        int id=LOWORD(wp);
        if(id==203){wchar_t path[32768]{};OPENFILENAMEW dialog{};dialog.lStructSize=sizeof(dialog);dialog.hwndOwner=w;dialog.lpstrFile=path;dialog.nMaxFile=32768;dialog.lpstrFilter=L"Installed Windows savers\0*.scr\0";dialog.Flags=OFN_FILEMUSTEXIST|OFN_NOCHANGEDIR;
            if(GetOpenFileNameW(&dialog))SetDlgItemTextW(w,201,path);}
        else if(id==204){BROWSEINFOW browse{};browse.hwndOwner=w;browse.lpszTitle=L"Choose this monitor's photo folder";browse.ulFlags=BIF_RETURNONLYFSDIRS|BIF_NEWDIALOGSTYLE;
            auto item=SHBrowseForFolderW(&browse);if(item){wchar_t path[32768]{};if(SHGetPathFromIDListEx(item,path,32768,GPFIDL_DEFAULT))SetDlgItemTextW(w,202,path);CoTaskMemFree(item);}}
        else if(id==212){CHOOSECOLORW color{};COLORREF custom[16]{};color.lStructSize=sizeof(color);color.hwndOwner=w;color.lpCustColors=custom;color.Flags=CC_FULLOPEN|CC_RGBINIT;
            int rgb=0;Number(Utf8(ControlText(w,213)),rgb);color.rgbResult=RGB((rgb>>16)&255,(rgb>>8)&255,rgb&255);
            if(ChooseColorW(&color))SetDlgItemInt(w,213,(GetRValue(color.rgbResult)<<16)|(GetGValue(color.rgbResult)<<8)|GetBValue(color.rgbResult),FALSE);}
        else if(id==220&&selection>=0&&selection<static_cast<int>(displays.size())) {
            BOOL a,b,c,d;int interval=GetDlgItemInt(w,205,&a,FALSE),current=GetDlgItemInt(w,209,&b,FALSE),all=GetDlgItemInt(w,210,&c,FALSE),color=GetDlgItemInt(w,213,&d,FALSE);
            if(!a||!b||!c||!d||interval<5||interval>3600||current<1||current>12||all<1||all>12||current==all||color<0||color>0xffffff){MessageBoxW(w,L"Use 5–3600 seconds, distinct F1–F12 hotkeys and a valid background color.",L"Invalid options",MB_OK);return 0;}
            auto& p=draft.monitors[displays[selection].id];auto path=ControlText(w,201),folder=ControlText(w,202);
            if(!path.empty()&&!LocalFile(path,L".scr")){MessageBoxW(w,L"Select an existing .scr file on a drive. Savers run as programs: choose a trusted installed saver.",L"Invalid saver",MB_OK);return 0;}
            if(!folder.empty()){DWORD attrs=GetFileAttributesW(Extended(folder).c_str());if(folder.size()<3||folder[1]!=L':'||attrs==INVALID_FILE_ATTRIBUTES||!(attrs&FILE_ATTRIBUTE_DIRECTORY)||(attrs&FILE_ATTRIBUTE_REPARSE_POINT)){MessageBoxW(w,L"Choose an accessible folder on a drive, without a junction or symbolic link.",L"Invalid photo folder",MB_OK);return 0;}}
            p.custom=Utf8(path);p.folder=Utf8(folder);p.slideSeconds=interval;p.placement=static_cast<int>(SendDlgItemMessageW(w,206,CB_GETCURSEL,0,0));p.shuffle=IsDlgButtonChecked(w,207)==BST_CHECKED;p.recursive=IsDlgButtonChecked(w,208)==BST_CHECKED;p.background=color;
            draft.hotkeys=IsDlgButtonChecked(w,211)==BST_CHECKED;draft.currentKey=current;draft.allKey=all;DestroyWindow(w);
        }else if(id==221||id==IDCANCEL)DestroyWindow(w);return 0;
    }
    if(msg==WM_CLOSE){DestroyWindow(w);return 0;}
    if(msg==WM_DPICHANGED){SettingsDpiChanged(w,wp,lp,optionsLayout,optionsFont,576,optionsScroll);return 0;}
    if(msg==WM_DESTROY){options=nullptr;if(editor){EnableWindow(editor,TRUE);SetForegroundWindow(editor);}return 0;}
    if(msg==WM_NCDESTROY){optionsLayout.controls.clear();if(optionsFont){DeleteObject(optionsFont);optionsFont=nullptr;}}
    return DefWindowProcW(w,msg,wp,lp);
}
void ShowSaverOptions() {
    if(options||selection<0||selection>=static_cast<int>(displays.size()))return;StoreMonitorDraft();
    auto& p=draft.monitors[displays[selection].id];int dpi=GetDpiForWindow(editor);optionsLayout={};optionsLayout.dpi=dpi;auto px=[&](int value){return MulDiv(value,dpi,96);};
    optionsScroll=0;options=CreateWindowExW(WS_EX_DLGMODALFRAME,kOptions,L"Liminal — Saver files, slideshow and hotkeys",WS_CAPTION|WS_SYSMENU|WS_VSCROLL,CW_USEDEFAULT,CW_USEDEFAULT,px(720),px(620),editor,nullptr,GetModuleHandleW(nullptr),nullptr);if(!options)return;FitSettings(options,720,620);
    dpi=GetDpiForWindow(options);optionsLayout.dpi=dpi;
    optionsFont=SettingsFont(dpi);ThemeChrome(options);
    auto control=[&](const wchar_t* cls,const wchar_t* text,DWORD style,int x,int y,int width,int height,int id){auto child=CreateWindowExW(0,cls,text,WS_CHILD|WS_VISIBLE|style,px(x),px(y),px(width),px(height),options,reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),GetModuleHandleW(nullptr),nullptr);optionsLayout.controls.push_back({child,x,y,width,height});ThemeControl(child,cls);SendMessageW(child,WM_SETFONT,reinterpret_cast<WPARAM>(optionsFont?optionsFont:GetStockObject(DEFAULT_GUI_FONT)),TRUE);return child;};
    control(L"STATIC",L"Local saver program (.scr); select Custom in the monitor assignment",0,16,16,655,24,0);
    control(L"EDIT",Wide(p.custom).c_str(),WS_BORDER|ES_AUTOHSCROLL|WS_TABSTOP,16,44,525,26,201);control(L"BUTTON",L"Browse…",BS_PUSHBUTTON|WS_TABSTOP,555,44,110,26,203);
    control(L"STATIC",L"Independent photo folder; select Photo slideshow in the assignment",0,16,86,655,24,0);
    control(L"EDIT",Wide(p.folder).c_str(),WS_BORDER|ES_AUTOHSCROLL|WS_TABSTOP,16,114,525,26,202);control(L"BUTTON",L"Browse…",BS_PUSHBUTTON|WS_TABSTOP,555,114,110,26,204);
    control(L"STATIC",L"Seconds per photo (5–3600)       Placement",0,16,156,650,24,0);
    control(L"EDIT",L"",WS_BORDER|ES_NUMBER|WS_TABSTOP,16,184,200,26,205);SetDlgItemInt(options,205,p.slideSeconds,FALSE);
    control(L"COMBOBOX",L"",CBS_DROPDOWNLIST|CBS_OWNERDRAWFIXED|CBS_HASSTRINGS|WS_VSCROLL|WS_TABSTOP,240,184,425,200,206);
    for(auto label:{L"Fit",L"Fill (crop)",L"Stretch",L"Center at original size",L"Tile",L"Fit without enlarging"})SendDlgItemMessageW(options,206,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(label));SendDlgItemMessageW(options,206,CB_SETCURSEL,p.placement,0);
    control(L"BUTTON",L"Shuffle playlist",BS_AUTOCHECKBOX|WS_TABSTOP,16,225,260,26,207);CheckDlgButton(options,207,p.shuffle?BST_CHECKED:BST_UNCHECKED);
    control(L"BUTTON",L"Include subfolders",BS_AUTOCHECKBOX|WS_TABSTOP,310,225,320,26,208);CheckDlgButton(options,208,p.recursive?BST_CHECKED:BST_UNCHECKED);
    control(L"BUTTON",L"Background color…",BS_PUSHBUTTON|WS_TABSTOP,16,264,240,28,212);control(L"EDIT",L"",WS_BORDER|ES_NUMBER|WS_TABSTOP,280,264,210,28,213);SetDlgItemInt(options,213,p.background,FALSE);
    control(L"BUTTON",L"Enable Ctrl+Alt+F-key sticky toggle shortcuts (all monitors)",BS_AUTOCHECKBOX|WS_TABSTOP,16,310,650,28,211);CheckDlgButton(options,211,draft.hotkeys?BST_CHECKED:BST_UNCHECKED);
    control(L"STATIC",L"Current monitor F-number          All enabled monitors F-number",0,16,352,650,24,0);
    control(L"EDIT",L"",WS_BORDER|ES_NUMBER|WS_TABSTOP,16,380,240,26,209);SetDlgItemInt(options,209,draft.currentKey,FALSE);
    control(L"EDIT",L"",WS_BORDER|ES_NUMBER|WS_TABSTOP,310,380,240,26,210);SetDlgItemInt(options,210,draft.allKey,FALSE);
    auto text=L"Hotkeys toggle sticky mode; pointer selects the current monitor. Emergency exit remains Ctrl+Alt+Shift+F12.\nPhotos use JPEG, PNG, BMP or GIF (first frame); bounded to 2000 files.\n"+hotkeyStatus;
    control(L"STATIC",text.c_str(),0,16,430,650,76,0);
    control(L"BUTTON",L"Apply to settings draft",BS_PUSHBUTTON|WS_TABSTOP,16,530,330,32,220);control(L"BUTTON",L"Cancel",BS_PUSHBUTTON|WS_TABSTOP,380,530,280,32,221);
    LayoutSettings(options,optionsLayout,576,optionsScroll);EnableWindow(editor,FALSE);
#ifndef AEGIS_HARNESS
    ShowWindow(options,SW_SHOWNORMAL);
#endif
}
int editorScroll=0;
LRESULT CALLBACK EditorProc(HWND w,UINT msg,WPARAM wp,LPARAM lp) {
    LRESULT themed{};if(ThemeMessage(w,msg,wp,lp,themed))return themed;
    if(msg==WM_COMMAND) {
        int id=LOWORD(wp);
        if(id==120&&HIWORD(wp)==CBN_SELCHANGE) {
            if(!ValidMonitorNumbers()){SendDlgItemMessageW(editor,120,CB_SETCURSEL,selection,0);MessageBoxW(w,L"Monitor times must be nonnegative integers.",L"Invalid settings",MB_OK);return 0;}
            StoreMonitorDraft(); LoadMonitorDraft();
        }
        else if(id==130) {
            if(!ValidMonitorNumbers()){MessageBoxW(w,L"Monitor times must be nonnegative integers.",L"Invalid settings",MB_OK);return 0;}
            StoreMonitorDraft(); BOOL ok1,ok2,ok3;
            draft.timeout=GetDlgItemInt(w,101,&ok1,FALSE); draft.poll=GetDlgItemInt(w,102,&ok2,FALSE); draft.padding=GetDlgItemInt(w,103,&ok3,FALSE);
            if(!ok1||!ok2||!ok3) { MessageBoxW(w,L"Timeout, interval and padding must be nonnegative integers.",L"Invalid settings",MB_OK); return 0; }
            bool* flags[]={&draft.automatic,&draft.perInput,&draft.media,&draft.perMedia,&draft.muted,&draft.debug};
            for(int i=0;i<6;++i) *flags[i]=IsDlgButtonChecked(w,110+i)==BST_CHECKED;
            if(draft.automatic&&LegacyStartupPresent()) { MessageBoxW(w,L"The legacy OLED Aegis Run entry still exists. Disable its startup and exit the old app before enabling automatic activation here.",L"Migration action required",MB_OK); return 0; }
            if(Save(draft)) { PopulateEditor(); SetWindowTextW(w,L"Liminal OLED Guard Settings — saved"); }
            else SetWindowTextW(w,L"Liminal OLED Guard Settings — SAVE FAILED (previous settings retained)");
        } else if(id==131) ImportLegacy(w);
        else if(id==132) DestroyWindow(w);
        else if(id==149){if(ValidMonitorNumbers())ShowSaverOptions();else MessageBoxW(w,L"Monitor times must be nonnegative integers.",L"Invalid settings",MB_OK);}
        else if(id==148&&selection>=0&&selection<static_cast<int>(displays.size())) {
            auto selected=displays[selection].id;bool active=false;for(auto& task:powerTasks)if(task->id==selected)active=true;
            if(active)Notice(L"Stop this monitor and wait for hardware cleanup before resetting its fault.");
            else if(MessageBoxW(w,L"Confirm the display is awake using its physical button. Clear the saved hardware fault to permit another explicit power attempt?",L"Reset hardware fault",MB_YESNO|MB_ICONQUESTION)==IDYES) {
                if(!PowerPending(selected)||DeleteFileW(Extended(PowerMarker(selected)).c_str()))powerStatus.erase(selected);else Notice(L"Could not clear hardware fault file; check profile storage permissions.");
            }
        }
        return 0;
    }
    if(msg==WM_CLOSE) { DestroyWindow(w); return 0; }
    if(msg==WM_TIMER) {UpdateEditorStatus();return 0;}
    if(ScrollSettings(w,msg,wp,lp,800,editorScroll,editorLayout))return 0;
    if(msg==WM_DESTROY) { editor=nullptr; selection=-1; return 0; }
    if(msg==WM_NCDESTROY){editorLayout.controls.clear();if(editorFont){DeleteObject(editorFont);editorFont=nullptr;}}
    if(msg==WM_DPICHANGED) {SettingsDpiChanged(w,wp,lp,editorLayout,editorFont,800,editorScroll);return 0;}
    return DefWindowProcW(w,msg,wp,lp);
}
void ShowSettings() {
    if(editor) { SetForegroundWindow(editor); return; }
    UINT dpi=GetDpiForSystem(); int scale=static_cast<int>(dpi);editorLayout={};editorLayout.dpi=scale;
    auto px=[&](int v){return MulDiv(v,scale,96);};
    editorScroll=0;editor=CreateWindowExW(WS_EX_APPWINDOW,kEditor,L"Liminal OLED Guard Settings",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_VSCROLL,
        CW_USEDEFAULT,CW_USEDEFAULT,px(780),px(840),nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    if(!editor) return;
    scale=static_cast<int>(GetDpiForWindow(editor)); if(scale<=0) scale=96;
    editorLayout.dpi=scale;
    FitSettings(editor,780,840);
    editorFont=SettingsFont(scale);ThemeChrome(editor);
    auto control=[&](const wchar_t* cls,const wchar_t* text,DWORD style,int x,int y,int width,int height,int id) {
        HWND c=CreateWindowExW(0,cls,text,WS_CHILD|WS_VISIBLE|style,px(x),px(y),px(width),px(height),editor,reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),GetModuleHandleW(nullptr),nullptr);
        editorLayout.controls.push_back({c,x,y,width,height});ThemeControl(c,cls);
        SendMessageW(c,WM_SETFONT,reinterpret_cast<WPARAM>(editorFont?editorFont:GetStockObject(DEFAULT_GUI_FONT)),TRUE); return c;
    };
    control(L"STATIC",L"Timeout seconds (5–3600) / check interval ms (250–10000) / padding px (0–1024)",0,16,16,655,24,0);
    for(int i=0;i<3;++i) control(L"EDIT",L"",WS_BORDER|WS_TABSTOP|ES_NUMBER,16+i*216,44,195,26,101+i);
    const wchar_t* labels[]={L"Automatic idle activation (requires Windhawk running)",L"Per-monitor input (keyboard credits cursor and foreground displays)",L"Suppress automatic activation during media playback",L"Per-monitor media attribution (process/window heuristic)",L"Also suppress for muted or silent active audio sessions",L"Optional diagnostics (bounded to 1000 events per host; no titles or input data)"};
    for(int i=0;i<6;++i) control(L"BUTTON",labels[i],BS_AUTOCHECKBOX|WS_TABSTOP,16,84+i*32,650,28,110+i);
    control(L"STATIC",L"Monitor assignment (disconnected preferences are retained)",0,16,284,650,22,0);
    control(L"COMBOBOX",L"",CBS_DROPDOWNLIST|CBS_OWNERDRAWFIXED|CBS_HASSTRINGS|WS_VSCROLL|WS_TABSTOP,16,312,650,160,120);
    control(L"BUTTON",L"Enabled",BS_AUTOCHECKBOX|WS_TABSTOP,16,350,130,26,121);
    control(L"COMBOBOX",L"",CBS_DROPDOWNLIST|CBS_OWNERDRAWFIXED|CBS_HASSTRINGS|WS_VSCROLL|WS_TABSTOP,160,350,506,200,122);
    SendDlgItemMessageW(editor,122,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(L"Native black"));
    for(int i=0;i<6;++i) { auto label=std::wstring(savers[i])+(Available(i)?L" (unqualified)":L" (not installed)"); SendDlgItemMessageW(editor,122,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(label.c_str())); }
    for(auto label:{L"Custom installed .scr",L"Independent photo slideshow"})SendDlgItemMessageW(editor,122,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(label));
    control(L"STATIC",L"Monitor idle seconds (0 = global)    Input scope                 Media override",0,16,390,695,22,0);
    control(L"EDIT",L"",WS_BORDER|WS_TABSTOP|ES_NUMBER,16,414,170,26,140);
    control(L"COMBOBOX",L"",CBS_DROPDOWNLIST|CBS_OWNERDRAWFIXED|CBS_HASSTRINGS|WS_VSCROLL|WS_TABSTOP,202,414,225,140,141);
    control(L"COMBOBOX",L"",CBS_DROPDOWNLIST|CBS_OWNERDRAWFIXED|CBS_HASSTRINGS|WS_VSCROLL|WS_TABSTOP,443,414,245,140,142);
    for(auto label:{L"Use global setting",L"Any monitor activity",L"This monitor's activity"})SendDlgItemMessageW(editor,141,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(label));
    for(auto label:{L"Use global setting",L"Ignore media",L"Suppress for media"})SendDlgItemMessageW(editor,142,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(label));
    control(L"STATIC",L"Seconds after presentation starts:    Switch saver to black (0 = never)    Hardware off (0 = manual only)",0,16,454,700,24,0);
    control(L"EDIT",L"",WS_BORDER|WS_TABSTOP|ES_NUMBER,280,482,170,26,143);
    control(L"EDIT",L"",WS_BORDER|WS_TABSTOP|ES_NUMBER,478,482,210,26,145);
    control(L"BUTTON",L"Opt in: DDC/CI hardware soft-off for this monitor (experimental)",BS_AUTOCHECKBOX|WS_TABSTOP,16,518,690,26,144);
    control(L"BUTTON",L"Keep this monitor awake while a foreground app is fullscreen",BS_AUTOCHECKBOX|WS_TABSTOP,16,550,690,26,146);
    control(L"STATIC",L"",0,16,582,690,44,147);
    control(L"BUTTON",L"Reset hardware fault…",BS_PUSHBUTTON|WS_TABSTOP,16,632,235,30,148);
    control(L"BUTTON",L"Saver files / slideshow / hotkeys…",BS_PUSHBUTTON|WS_TABSTOP,270,632,420,30,149);
    control(L"STATIC",L"Hardware wake can fail: use the monitor's power button. DDC/CI depends on hardware/driver support.\nSave before tray Preview/Configure. Padding can cover adjacent displays.\nActivity/media attribution is heuristic. Sticky mode ignores input; tray Stop and emergency exit remain available.",0,16,674,700,66,0);
    control(L"BUTTON",L"Save",BS_PUSHBUTTON|WS_TABSTOP,16,754,150,32,130);
    control(L"BUTTON",L"Import legacy INI…",BS_PUSHBUTTON|WS_TABSTOP,182,754,260,32,131);
    control(L"BUTTON",L"Close",BS_PUSHBUTTON|WS_TABSTOP,458,754,230,32,132);
    PopulateEditor();LayoutSettings(editor,editorLayout,800,editorScroll);SetTimer(editor,1,500,nullptr);
#ifndef AEGIS_HARNESS
    ShowWindow(editor,SW_SHOWNORMAL);
#endif
}
void StopMonitor(const std::string& id) {
    auto it=controller.nodes.find(id);if(it!=controller.nodes.end())it->second={GetTickCount64(),++controller.serial,State::Desktop,false};
    for(auto& r:runs)if(r->id==id)r->cancel=true;for(auto& task:powerTasks)if(task->id==id)task->cancel=true;
}
void ManualAll(bool sticky=false) { StopMonitor("@span");for(auto& d:displays) if(d.identified) controller.Manual(d.id,GetTickCount64(),sticky); Reconcile(); }
bool Span(int saver,bool sticky=false,const std::string& source="") {
    if(displays.empty()||controller.blocked||controller.paused)return false;
    for(auto& d:displays)if(!d.identified||!controller.Pref(d.id).enabled)return false;
    Reset();spanningDisplay=displays.front();spanningDisplay.id="@span";spanningDisplay.alias=source.empty()?displays.front().id:source;
    controller.spanPreference=controller.Pref(spanningDisplay.alias);controller.spanPreference.hardware=false;controller.spanPreference.powerAfter=0;
    for(auto& d:displays) {auto& r=spanningDisplay.rect;r.left=std::min(r.left,d.rect.left);r.top=std::min(r.top,d.rect.top);r.right=std::max(r.right,d.rect.right);r.bottom=std::max(r.bottom,d.rect.bottom);}
    controller.nodes["@span"]={};controller.Manual("@span",GetTickCount64(),sticky,saver);Reconcile();return true;
}
void Menu(HWND w) {
    HMENU menu=CreatePopupMenu(); if(!menu) return;
    bool stopIntent=controller.Any();std::vector<std::string> menuIds;
    AppendMenuW(menu,MF_STRING,1,stopIntent?L"Stop all":L"Start enabled monitors");
    AppendMenuW(menu,MF_STRING|(controller.paused?MF_CHECKED:0),2,L"Pause for this session");
    AppendMenuW(menu,MF_STRING,3,L"Settings / import…");
    AppendMenuW(menu,MF_STRING,5,L"Start enabled monitors (sticky)");
    AppendMenuW(menu,MF_STRING,6,L"Span desktop using current monitor's saver");
    AppendMenuW(menu,MF_STRING,7,L"Black all enabled monitors");
    for(size_t i=0;i<displays.size();++i) {
        auto& d=displays[i];menuIds.push_back(d.id); HMENU sub=CreatePopupMenu(); if(!sub) continue;
        bool enabled=d.identified&&controller.Pref(d.id).enabled;
        AppendMenuW(sub,MF_STRING|(enabled?0:MF_GRAYED),100+i*6,L"Preview saved assignment");
        AppendMenuW(sub,MF_STRING,101+i*6,L"Stop / wake this monitor");
        AppendMenuW(sub,MF_STRING|((d.identified&&controller.Pref(d.id).saver>=0&&controller.Pref(d.id).saver<=6)?0:MF_GRAYED),102+i*6,L"Configure saved saver (shared Windows preferences)");
        AppendMenuW(sub,MF_STRING|(enabled?0:MF_GRAYED),103+i*6,L"Toggle sticky presentation");
        AppendMenuW(sub,MF_STRING|(enabled?0:MF_GRAYED),104+i*6,L"Black this monitor");
        AppendMenuW(sub,MF_STRING|((enabled&&controller.Pref(d.id).hardware)?0:MF_GRAYED),105+i*6,L"Hardware off now (opt-in)");
        auto label=d.label+L" — "+StateLabel(controller.nodes[d.id].state);
        AppendMenuW(menu,MF_POPUP,reinterpret_cast<UINT_PTR>(sub),label.c_str());
    }
    AppendMenuW(menu,MF_STRING,4,L"Exit until mod re-enabled");
    POINT point{}; GetCursorPos(&point); SetForegroundWindow(w);
    UINT choice=TrackPopupMenu(menu,TPM_RETURNCMD|TPM_NONOTIFY,point.x,point.y,0,w,nullptr);
    DestroyMenu(menu); PostMessageW(w,WM_NULL,0,0);
    if(choice==1) { if(stopIntent) Reset(); else ManualAll(); }
    else if(choice==2) { controller.paused=!controller.paused; Reset(); }
    else if(choice==3) ShowSettings(); else if(choice==4) SetEvent(stopEvent);
    else if(choice==5) ManualAll(true);
    else if(choice==6) {HMONITOR monitor=MonitorFromPoint(point,MONITOR_DEFAULTTONEAREST);int saver=-1;std::string source;for(auto& d:displays)if(d.handle==monitor){saver=controller.Pref(d.id).saver;source=d.id;}
        if(!Span(saver,false,source))Notice(L"Spanning requires every connected monitor to be identified and enabled, and protection unpaused.");}
    else if(choice==7) {StopMonitor("@span");for(auto& d:displays)if(d.identified)controller.Manual(d.id,GetTickCount64(),false,-1);Reconcile();}
    else if(choice>=100) {
        size_t index=(choice-100)/6; int action=(choice-100)%6; if(index>=menuIds.size()) return;
        auto selected=std::find_if(displays.begin(),displays.end(),[&](const Display& d){return d.id==menuIds[index];});
        if(selected==displays.end()) return;auto& d=*selected;
        StopMonitor("@span");
        if(action==0) controller.Manual(d.id,GetTickCount64());
        else if(action==1) StopMonitor(d.id);
        else if(action==2) { StopMonitor(d.id);Reconcile(); if(!AddRun(d,0,controller.Pref(d.id).saver,true)) Notice(L"Configuration not started; stop existing preview/configuration and retry."); }
        else if(action==3) {if(controller.nodes[d.id].sticky&&Running(controller.nodes[d.id].state))StopMonitor(d.id);else controller.Manual(d.id,GetTickCount64(),true);}
        else if(action==4||action==5) {controller.Manual(d.id,GetTickCount64(),false,-1);
            if(action==5&&Running(controller.nodes[d.id].state))controller.nodes[d.id].powerRequested=true;}
        Reconcile();
    }
}
bool SessionLocked() {
    LPWSTR data=nullptr; DWORD bytes=0;bool result=true;
    if(WTSQuerySessionInformationW(WTS_CURRENT_SERVER_HANDLE,WTS_CURRENT_SESSION,WTSSessionInfoEx,&data,&bytes)) {
        if(bytes>=sizeof(WTSINFOEXW)) {auto info=reinterpret_cast<WTSINFOEXW*>(data);
            result=info->Level!=1||info->Data.WTSInfoExLevel1.SessionState!=WTSActive||info->Data.WTSInfoExLevel1.SessionFlags!=WTS_SESSIONSTATE_UNLOCK;}
        WTSFreeMemory(data);
    } return result;
}
LRESULT CALLBACK WindowProc(HWND w,UINT msg,WPARAM wp,LPARAM lp) {
    if(taskbar&&msg==taskbar&&w==ui) { trayPresent=false; SetBlocked();nextTray=0; return 0; }
    switch(msg) {
#ifdef AEGIS_HARNESS
    case WM_APP+100: {ShowSettings();bool created=editor&&GetDlgItem(editor,130)&&GetDlgItem(editor,122);if(editor) DestroyWindow(editor);return created&&editorFont==nullptr;}
    case WM_APP+101: return reinterpret_cast<LRESULT(*)()>(lp)(); // same-process test action on actual UI owner
#endif
    case WM_MOUSEACTIVATE:return MA_NOACTIVATE;
    case WM_SETCURSOR:if(w!=ui) {SetCursor(nullptr);return TRUE;}break;
    case WM_PAINT:{PAINTSTRUCT p{}; HDC dc=BeginPaint(w,&p); FillRect(dc,&p.rcPaint,static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));
        for(auto& r:runs)if(r->window==w){std::lock_guard lock(r->frameLock);if(r->frame){Gdiplus::Graphics graphics(dc);int offset=controller.config.padding;graphics.DrawImage(r->frame.get(),offset,offset,r->width,r->height);}break;}
        EndPaint(w,&p); return 0;}
    case WM_HOTKEY:
        if(wp==11){if(controller.Any())Reset();else ManualAll(true);}
        else if(wp==10){POINT point{};if(GetCursorPos(&point)){HMONITOR monitor=MonitorFromPoint(point,MONITOR_DEFAULTTONULL);StopMonitor("@span");for(auto& d:displays)if(d.handle==monitor&&d.identified){if(Running(controller.nodes[d.id].state))StopMonitor(d.id);else controller.Manual(d.id,GetTickCount64(),true);}}}Reconcile();return 0;
    case WM_INPUT:Input(reinterpret_cast<HRAWINPUT>(lp));break;
    case kTray:if(lp==WM_RBUTTONUP) Menu(w); else if(lp==WM_LBUTTONUP) { if(controller.Any()) Reset(); else ManualAll(); } return 0;
    case kReload:Reload();return 0;
    case WM_SETTINGCHANGE:case WM_THEMECHANGED:case WM_SYSCOLORCHANGE:RefreshSettingsTheme();return 0;
    case WM_DISPLAYCHANGE:case WM_DPICHANGED:Reset();topologyPending=true;return 0;
    case WM_WTSSESSION_CHANGE:
        if(wp==WTS_SESSION_LOCK||wp==WTS_CONSOLE_DISCONNECT||wp==WTS_REMOTE_DISCONNECT) locked=true;
        if(wp==WTS_SESSION_UNLOCK||wp==WTS_CONSOLE_CONNECT||wp==WTS_REMOTE_CONNECT) {locked=SessionLocked();topologyPending=true;}
        SetBlocked();return 0;
    case WM_POWERBROADCAST:
        if(wp==PBT_APMSUSPEND) suspended=true;
        if(wp==PBT_APMRESUMEAUTOMATIC||wp==PBT_APMRESUMESUSPEND) {suspended=false;topologyPending=true;}
        if(wp==PBT_POWERSETTINGCHANGE) { auto p=reinterpret_cast<POWERBROADCAST_SETTING*>(lp);
            if(p&&p->PowerSetting==GUID_CONSOLE_DISPLAY_STATE&&p->DataLength==sizeof(DWORD)) { DWORD state=0; memcpy(&state,p->Data,sizeof(state)); displayOff=state==0; }
        } SetBlocked();return TRUE;
    case WM_TIMER:{
        if(WaitForSingleObject(stopEvent,0)==WAIT_OBJECT_0) { PostMessageW(w,kQuit,0,0); return 0; }
        if(topologyPending) { if(editor) DestroyWindow(editor); RefreshTopology(); }
        auto now=GetTickCount64();
#ifdef AEGIS_HARNESS
        if(!injectedObservations) {CheckInputFallback();ObserveForeground();}
#else
        CheckInputFallback();ObserveForeground();
#endif
        if(now>=nextPoll) { Media m; {std::lock_guard lock(observationLock);m=observation;} controller.Tick(now,m);nextPoll=now+controller.config.poll; }
        // Identity failures and clone sources are ineligible even for automatic policy.
        for(auto& d:displays) if(!d.identified) controller.nodes[d.id].state=State::Disabled;
        Reconcile();
#ifdef AEGIS_HARNESS
        if(injectedObservations) return 0;
#endif
        if(now>=nextTray) { bool previous=trayPresent;Tray();if(previous!=trayPresent) SetBlocked();nextTray=now+(trayPresent?5000:1000); } return 0;
    }
    case WM_QUERYENDSESSION:SetEvent(stopEvent);return TRUE;
    case WM_CLOSE:if(w==ui) SetEvent(stopEvent);return 0;
    case kQuit:EndMenu();PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(w,msg,wp,lp);
}
DWORD WINAPI SafetyMain(void*) {
    MSG msg{}; PeekMessageW(&msg,nullptr,0,0,PM_NOREMOVE);
#ifdef AEGIS_HARNESS
    safetyOK=true; // event-driven cancellation tested; never steals the live mod's hotkey
#else
    safetyOK=!!RegisterHotKey(nullptr,1,MOD_CONTROL|MOD_ALT|MOD_SHIFT|MOD_NOREPEAT,VK_F12);
#endif
    SetEvent(safetyReady);
    if(!safetyOK) SetEvent(stopEvent);
    while(safetyOK) {
        DWORD status=MsgWaitForMultipleObjects(1,&stopEvent,FALSE,250,QS_ALLINPUT);
        if(status==WAIT_OBJECT_0||status==WAIT_FAILED) break;
        while(PeekMessageW(&msg,nullptr,0,0,PM_REMOVE)) if(msg.message==WM_HOTKEY) SetEvent(stopEvent);
    }
    { std::lock_guard lock(registryLock); for(auto window:ownedWindows) ShowWindowAsync(window,SW_HIDE); for(auto& [job,window]:ownedJobs) {
        if(window) ShowWindowAsync(window,SW_HIDE); TerminateJobObject(job,0);
    } }
    PostMessageW(ui,kQuit,0,0); UnregisterHotKey(nullptr,1); return 0;
}
DWORD WINAPI UiMain(void*) {
    bool dpiOK=SetThreadDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2)!=nullptr;
    HRESULT com=CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);
    Gdiplus::GdiplusStartupInput imagingInput;bool imagingOK=Gdiplus::GdiplusStartup(&imagingToken,&imagingInput,nullptr)==Gdiplus::Ok;
    ReadUiTheme();if(imagingOK){theme.small=AegisIcon(GetSystemMetrics(SM_CXSMICON),false);theme.large=AegisIcon(GetSystemMetrics(SM_CXICON),false);theme.active=AegisIcon(GetSystemMetrics(SM_CXSMICON),true);}
    WNDCLASSW wc{}; wc.lpfnWndProc=WindowProc; wc.hInstance=GetModuleHandleW(nullptr); wc.lpszClassName=kClass;
    wc.hCursor=LoadCursorW(nullptr,IDC_ARROW); wc.hbrBackground=static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH));
    bool registered=!!RegisterClassW(&wc); wc.lpfnWndProc=EditorProc; wc.lpszClassName=kEditor; wc.hbrBackground=reinterpret_cast<HBRUSH>(COLOR_WINDOW+1);
    bool editorRegistered=registered&&RegisterClassW(&wc);
    wc.lpfnWndProc=OptionsProc;wc.lpszClassName=kOptions;bool optionsRegistered=editorRegistered&&RegisterClassW(&wc);
    if(optionsRegistered) ui=CreateWindowExW(WS_EX_TOOLWINDOW,kClass,L"Liminal controller",WS_POPUP,0,0,0,0,nullptr,nullptr,wc.hInstance,nullptr);
    RAWINPUTDEVICE raw[]={{1,2,RIDEV_INPUTSINK,ui},{1,6,RIDEV_INPUTSINK,ui}};
    bool inputOK=ui&&RegisterRawInputDevices(raw,2,sizeof(raw[0]));
    taskbar=RegisterWindowMessageW(L"TaskbarCreated");
    bool sessionOK=ui&&WTSRegisterSessionNotification(ui,NOTIFY_FOR_THIS_SESSION);
    locked=SessionLocked();
    controller.blocked=locked;
    if(ui) powerNotification=RegisterPowerSettingNotification(ui,&GUID_CONSOLE_DISPLAY_STATE,DEVICE_NOTIFY_WINDOW_HANDLE);
    std::wstring startupNotice;
#ifdef AEGIS_HARNESS
    // Harness never reads/writes the operator's saved preferences or arms idle.
    wchar_t testPath[32768]; GetModuleFileNameW(nullptr,testPath,32768); configPath=std::wstring(testPath)+L".test-settings";
#else
    configPath=ConfigPath();
#endif
    std::string text,error; DWORD code=0;
    if(!configPath.empty()&&ReadFileText(configPath,text,code)) {
        if(!Parse(text,controller.config,error)) { controller.config.automatic=false; startupNotice=L"Invalid configuration: automatic activation disabled; save settings to repair."; }
    } else if(code!=ERROR_FILE_NOT_FOUND&&code!=ERROR_PATH_NOT_FOUND) {controller.config.automatic=false;startupNotice=L"Cannot read configuration. Automatic activation disabled; check settings storage.";}
    if(LegacyStartupPresent()) { controller.config.automatic=false; startupNotice=L"Legacy startup detected; automatic activation withheld. Disable standalone startup and exit it before enabling automatic mode here."; }
    debug=controller.config.debug; RefreshTopology();
    if(ui) Tray();
#ifdef AEGIS_HARNESS
    controller.config.automatic=false; // test exemptions, never in mod
#endif
    controller.blocked=locked||!trayPresent;
    ready=dpiOK&&imagingOK&&theme.small&&theme.large&&theme.active&&ui&&inputOK&&sessionOK&&powerNotification&&SetTimer(ui,1,50,nullptr)&&!configPath.empty();
    if(ready)RegisterControls();
    if(ready&&!startupNotice.empty()) Notice(startupNotice.c_str());
    SetEvent(readyEvent); MSG msg{};
    if(ready) while(true) { int status=GetMessageW(&msg,nullptr,0,0); if(status<=0) break;
        HWND dialog=options?options:editor;if(!dialog||!IsDialogMessageW(dialog,&msg)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    }
    SetEvent(stopEvent); StopRuns();
    for(auto& task:powerTasks)if(task->worker.joinable())task->worker.join();powerTasks.clear();
    for(auto& r:runs) { if(r->worker.joinable()) r->worker.join(); if(r->window) { {std::lock_guard lock(registryLock);ownedWindows.erase(r->window);} DestroyWindow(r->window); } } runs.clear();
    if(editor) DestroyWindow(editor);
    RAWINPUTDEVICE remove[]={{1,2,RIDEV_REMOVE,nullptr},{1,6,RIDEV_REMOVE,nullptr}}; if(inputOK) RegisterRawInputDevices(remove,2,sizeof(remove[0]));
    if(powerNotification) { UnregisterPowerSettingNotification(powerNotification); powerNotification=nullptr; }
    if(ui) { UnregisterHotKey(ui,10);UnregisterHotKey(ui,11);KillTimer(ui,1); WTSUnRegisterSessionNotification(ui); Tray(true); DestroyWindow(ui); ui=nullptr; }
    if(optionsRegistered)UnregisterClassW(kOptions,wc.hInstance);
    if(editorRegistered) UnregisterClassW(kEditor,wc.hInstance); if(registered) UnregisterClassW(kClass,wc.hInstance);
    if(SUCCEEDED(com)) CoUninitialize();
    for(auto icon:{theme.small,theme.large,theme.active})if(icon)DestroyIcon(icon);theme.small=theme.large=theme.active=nullptr;
    if(theme.base)DeleteObject(theme.base);if(theme.surface)DeleteObject(theme.surface);theme.base=theme.surface=nullptr;
    if(imagingOK){Gdiplus::GdiplusShutdown(imagingToken);imagingToken=0;}
#ifndef AEGIS_HARNESS
    while(!startupComplete&&!unloading) Sleep(1);
    if(ready&&!unloading) { if(safetyThread) WaitForSingleObject(safetyThread,INFINITE); if(mediaThread) WaitForSingleObject(mediaThread,INFINITE); if(!unloading) ExitProcess(0); }
#endif
    return 0;
}
void Shutdown() {
    unloading=true; if(stopEvent) SetEvent(stopEvent); if(ui) PostMessageW(ui,kQuit,0,0);
    // Final joins are mandatory for DLL lifetime safety. Win32/COM/file calls
    // can stall inside the OS: no absolute unload bound is asserted.
    for(HANDLE h:{safetyThread,mediaThread,uiThread}) if(h) WaitForSingleObject(h,INFINITE);
    // Natural UI exit may also wait on worker handles. Close only after ALL
    // threads have ended, so no waiter can observe a reused/closed handle.
    for(HANDLE* h:{&safetyThread,&mediaThread,&uiThread}) if(*h) {CloseHandle(*h);*h=nullptr;}
    for(HANDLE* h:{&stopEvent,&readyEvent,&safetyReady,&singleton}) if(*h) { CloseHandle(*h); *h=nullptr; }
    ready=false;
}
bool Initialize() {
    unloading=false; ready=false; safetyOK=false; startupComplete=false; controller=Controller{};
    locked=suspended=displayOff=topologyPending=false; lastInputStamp=rawStamp=0; diagnostics=0;
    nextPoll=nextTray=0;trayPresent=false;powerStatus.clear();
#ifdef AEGIS_HARNESS
    singleton=CreateMutexW(nullptr,FALSE,(testStopName+L"-singleton").c_str());
#else
    singleton=CreateMutexW(nullptr,FALSE,L"Local\\OLED-Aegis-V1-Singleton");
#endif
    if(!singleton||GetLastError()==ERROR_ALREADY_EXISTS) { if(singleton) CloseHandle(singleton); singleton=nullptr; return false; }
    stopEvent=CreateEventW(nullptr,TRUE,FALSE,kStopName); readyEvent=CreateEventW(nullptr,TRUE,FALSE,nullptr); safetyReady=CreateEventW(nullptr,TRUE,FALSE,nullptr);
    if(!stopEvent||!readyEvent||!safetyReady) { Shutdown(); return false; }
#ifdef AEGIS_HARNESS
    if(initFault==1) {Shutdown();return false;}
#endif
    safetyThread=CreateThread(nullptr,0,SafetyMain,nullptr,0,nullptr);
    if(!safetyThread||WaitForSingleObject(safetyReady,5000)!=WAIT_OBJECT_0||!safetyOK) { Shutdown(); return false; }
#ifdef AEGIS_HARNESS
    if(initFault==2) {Shutdown();return false;}
#endif
    uiThread=CreateThread(nullptr,0,UiMain,nullptr,0,nullptr);
    if(!uiThread||WaitForSingleObject(readyEvent,10000)!=WAIT_OBJECT_0||!ready) { Shutdown(); return false; }
#ifdef AEGIS_HARNESS
    if(initFault==3) {Shutdown();return false;}
#endif
    mediaThread=CreateThread(nullptr,0,MediaMain,nullptr,0,nullptr);
    if(!mediaThread) { Shutdown(); return false; }
    startupComplete=true;
    return true;
}
} // namespace aegis

#ifndef AEGIS_HARNESS
// Stable 1.7.3 dedicated tool-host adapter, selectively adapted from the local
// original prototype. Hook/host lifecycle still requires actual Windhawk QA.
bool toolHost=false,launcher=false,powerHost=false;
std::string powerId,powerToken;HANDLE powerThread{};
DWORD WINAPI PowerEntry(void*) {ExitProcess(aegis::PowerGuardian(powerId,powerToken));return 0;}
DWORD WINAPI DedicatedEntry() { ExitThread(0); return 0; }
BOOL Wh_ModInit() {
    DWORD session=0; if(!ProcessIdToSessionId(GetCurrentProcessId(),&session)||session==0) return FALSE;
    int count=0; wchar_t** args=CommandLineToArgvW(GetCommandLineW(),&count); if(!args) return FALSE;
    bool excluded=false,other=false;
    for(int i=1;i<count;++i) {
        if(wcscmp(args[i],L"-service")==0||wcscmp(args[i],L"-service-start")==0||wcscmp(args[i],L"-service-stop")==0) excluded=true;
        if(wcscmp(args[i],L"-tool-mod")==0&&i+1<count) { toolHost=wcscmp(args[++i],WH_MOD_ID)==0; other=!toolHost; }
        if(wcscmp(args[i],L"-aegis-power")==0&&i+3<count) {
            powerHost=true;std::string encoded=aegis::Utf8(args[++i]);std::wstring mode=args[++i];
            powerToken=aegis::Utf8(args[++i]);
            if(!aegis::Unhex(encoded,powerId)||mode!=L"cycle")excluded=true;
        }
    }
    LocalFree(args); if(excluded||other) return FALSE; if(!toolHost) { launcher=true; return TRUE; }
    auto base=reinterpret_cast<BYTE*>(GetModuleHandleW(nullptr)); auto dos=reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    auto nt=reinterpret_cast<IMAGE_NT_HEADERS*>(base+dos->e_lfanew);
    if(!Wh_SetFunctionHook(base+nt->OptionalHeader.AddressOfEntryPoint,reinterpret_cast<void*>(DedicatedEntry),nullptr)) return FALSE;
    if(powerHost)return TRUE;
    if(!aegis::Initialize()) { aegis::Shutdown(); ExitProcess(1); } return TRUE;
}
void Wh_ModAfterInit() {
    if(powerHost){powerThread=CreateThread(nullptr,0,PowerEntry,nullptr,0,nullptr);if(!powerThread)ExitProcess(11);return;}
    if(!launcher) return;
    wchar_t path[32768]; DWORD n=GetModuleFileNameW(nullptr,path,32768); if(!n||n>=32768) return;
    std::wstring command=L"\""+std::wstring(path)+L"\" -tool-mod \""+WH_MOD_ID+L"\"";
    using CreateInternal=BOOL(WINAPI*)(HANDLE,LPCWSTR,LPWSTR,LPSECURITY_ATTRIBUTES,LPSECURITY_ATTRIBUTES,BOOL,DWORD,LPVOID,LPCWSTR,LPSTARTUPINFOW,LPPROCESS_INFORMATION,PHANDLE);
    auto create=reinterpret_cast<CreateInternal>(GetProcAddress(GetModuleHandleW(L"kernelbase.dll"),"CreateProcessInternalW")); if(!create) return;
    STARTUPINFOW si{}; si.cb=sizeof(si); PROCESS_INFORMATION pi{};
    if(create(nullptr,path,command.data(),nullptr,nullptr,FALSE,0,nullptr,nullptr,&si,&pi,nullptr)) { CloseHandle(pi.hThread); CloseHandle(pi.hProcess); }
}
void Wh_ModSettingsChanged() { if(toolHost&&aegis::ui) PostMessageW(aegis::ui,aegis::kReload,0,0); }
void Wh_ModUninit() {
    if(powerHost){aegis::Handle cancelled(OpenEventW(EVENT_MODIFY_STATE,FALSE,aegis::PowerCancelName(powerToken).c_str()));if(cancelled)SetEvent(cancelled);if(powerThread)WaitForSingleObject(powerThread,INFINITE);ExitProcess(12);}
    if(toolHost) { aegis::Shutdown(); ExitProcess(0); }
}
#endif
#endif // AEGIS_POLICY_ONLY
